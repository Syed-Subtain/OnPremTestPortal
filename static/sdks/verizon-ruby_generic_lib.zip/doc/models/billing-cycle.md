
# Billing Cycle

## Structure

`BillingCycle`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `year` | `String` | Optional | - |
| `month` | `String` | Optional | - |

## Example (as JSON)

```json
{
  "year": "2020",
  "month": "3"
}
```

