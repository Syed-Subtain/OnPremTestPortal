
# Attribute Identifier Enum

Attribute identifier.

## Enumeration

`AttributeIdentifierEnum`

## Fields

| Name |
|  --- |
| `NETWORK_BEARER` |
| `RADIO_SIGNAL_STRENGTH` |
| `LINK_QUALITY` |
| `CELL_ID` |
| `MANUFACTURER` |

## Example

```
RADIO_SIGNAL_STRENGTH
```

