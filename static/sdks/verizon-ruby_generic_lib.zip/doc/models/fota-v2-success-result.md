
# Fota V2 Success Result

Response to a successful request.

## Structure

`FotaV2SuccessResult`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `success` | `TrueClass \| FalseClass` | Required | - |

## Example (as JSON)

```json
{
  "success": true
}
```

