
# ESI Msubrequest

## Structure

`ESIMsubrequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `String` | Optional | - |
| `kind` | `String` | Optional | - |
| `status` | [`Status1Enum`](../../doc/models/status-1-enum.md) | Optional | - |

## Example (as JSON)

```json
{
  "id": "32-digit EID",
  "kind": "eid",
  "status": "success"
}
```

