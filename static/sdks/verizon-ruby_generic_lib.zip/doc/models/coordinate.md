
# Coordinate

## Structure

`Coordinate`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `latitude` | `String` | Optional | **Constraints**: *Maximum Length*: `10`, *Pattern*: `^\d2\.\d*$` |
| `longitude` | `String` | Optional | **Constraints**: *Maximum Length*: `10`, *Pattern*: `^\d2\.\d*$` |

## Example (as JSON)

```json
{
  "latitude": "latitude8",
  "longitude": "longitude2"
}
```

