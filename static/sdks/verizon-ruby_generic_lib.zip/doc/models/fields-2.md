
# Fields 2

List of fields affected by the event.

## Structure

`Fields2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `temperature` | `String` | Optional | - |

## Example (as JSON)

```json
{
  "temperature": "18.4"
}
```

