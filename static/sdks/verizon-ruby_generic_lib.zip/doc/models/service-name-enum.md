
# Service Name Enum

Service name

## Enumeration

`ServiceNameEnum`

## Fields

| Name |
|  --- |
| `LOCATION` |
| `FOTA` |

