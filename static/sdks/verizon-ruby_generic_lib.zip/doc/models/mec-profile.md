
# MEC Profile

## Structure

`MECProfile`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `profile_id` | `String` | Optional | - |
| `profile_name` | `String` | Optional | - |

## Example (as JSON)

```json
{
  "profileId": "HSS-EsmProfile_Enterprise",
  "profileName": "HSS EsmProfile Enterprise"
}
```

