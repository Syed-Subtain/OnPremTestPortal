
# Configuration

List of the field names and values to set.

## Structure

`Configuration`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `frequency` | `String` | Optional | - |

## Example (as JSON)

```json
{
  "frequency": "Low"
}
```

