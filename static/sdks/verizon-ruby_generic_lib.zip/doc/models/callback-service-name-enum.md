
# Callback Service Name Enum

The name of the callback service.

## Enumeration

`CallbackServiceNameEnum`

## Fields

| Name |
|  --- |
| `LOCATION` |
| `DEVICELOCATION` |

## Example

```
Location
```

