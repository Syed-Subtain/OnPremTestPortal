
# Enable Promo Exp

## Structure

`EnablePromoExp`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `enable_promo_exp` | `TrueClass \| FalseClass` | Optional | - |

## Example (as JSON)

```json
{
  "enablePromoExp": true
}
```

