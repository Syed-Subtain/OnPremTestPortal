
# Qos Device Id

## Structure

`QosDeviceId`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `String` | Optional | - |
| `kind` | `String` | Optional | - |

## Example (as JSON)

```json
{
  "id": "10-digit phone number",
  "kind": "mdn"
}
```

