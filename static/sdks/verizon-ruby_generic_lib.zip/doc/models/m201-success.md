
# M201 Success

## Structure

`M201success`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `request_id` | `String` | Optional | - |

## Example (as JSON)

```json
{
  "requestId": "be36accb-0a9a-4367-93ab-0af6c4ed256a"
}
```

