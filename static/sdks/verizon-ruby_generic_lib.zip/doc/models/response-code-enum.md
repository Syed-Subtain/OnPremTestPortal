
# Response Code Enum

Possible response codes.

## Enumeration

`ResponseCodeEnum`

## Fields

| Name |
|  --- |
| `INVALID_ACCESS` |
| `INVALID_PARAMETER` |
| `INTERNAL_ERROR` |
| `SUCCESS` |

## Example

```
INVALID_ACCESS
```

