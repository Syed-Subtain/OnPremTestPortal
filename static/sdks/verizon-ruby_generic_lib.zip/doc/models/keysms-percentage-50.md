
# Keysms Percentage 50

## Structure

`KeysmsPercentage50`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `key` | `String` | Optional | - |
| `value` | `TrueClass \| FalseClass` | Optional | - |

## Example (as JSON)

```json
{
  "key": "SmsPercentage50",
  "value": false
}
```

