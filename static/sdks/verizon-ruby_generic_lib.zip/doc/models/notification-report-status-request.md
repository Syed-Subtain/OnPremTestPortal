
# Notification Report Status Request

## Structure

`NotificationReportStatusRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `account_name` | `String` | Optional | The name of a billing account. |
| `device` | [`DeviceId`](../../doc/models/device-id.md) | Optional | An identifier for a single device. |
| `request_expiration_time` | `String` | Optional | The time at which the request expires. |
| `request_type` | `String` | Optional | The type of request. |

## Example (as JSON)

```json
{
  "accountName": "0868924207-00001",
  "device": {
    "kind": "imei",
    "id": "990013907835573"
  },
  "requestExpirationTime": "requestExpirationTime6",
  "requestType": "requestType8"
}
```

