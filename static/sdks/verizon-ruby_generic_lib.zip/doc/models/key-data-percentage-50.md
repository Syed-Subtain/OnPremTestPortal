
# Key Data Percentage 50

## Structure

`KeyDataPercentage50`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `key` | `String` | Optional | - |
| `value` | `TrueClass \| FalseClass` | Optional | - |

## Example (as JSON)

```json
{
  "key": "DataPercentage50",
  "value": false
}
```

