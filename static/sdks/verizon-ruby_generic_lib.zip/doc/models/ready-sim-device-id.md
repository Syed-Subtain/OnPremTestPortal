
# Ready Sim Device Id

## Structure

`ReadySimDeviceId`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `kind` | `String` | Optional | - |
| `id` | `String` | Optional | - |

## Example (as JSON)

```json
{
  "kind": "iccid",
  "id": "20-digit iccid"
}
```

