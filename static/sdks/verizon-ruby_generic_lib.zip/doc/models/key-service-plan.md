
# Key Service Plan

## Structure

`KeyServicePlan`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `key` | `String` | Optional | - |

## Example (as JSON)

```json
{
  "key": "ServicePlan"
}
```

