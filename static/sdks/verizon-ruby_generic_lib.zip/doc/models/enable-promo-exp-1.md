
# Enable Promo Exp 1

## Structure

`EnablePromoExp1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `key` | `String` | Optional | - |
| `value` | `TrueClass \| FalseClass` | Optional | - |

## Example (as JSON)

```json
{
  "key": "EnablePromoExp",
  "value": true
}
```

