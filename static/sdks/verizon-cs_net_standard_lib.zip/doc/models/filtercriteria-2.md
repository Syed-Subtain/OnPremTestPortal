
# Filtercriteria 2

## Structure

`Filtercriteria2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `FilterCriteria` | `object` | Optional | - |

## Example (as JSON)

```json
{
  "filterCriteria": [
    {
      "key1": "val1",
      "key2": "val2"
    }
  ]
}
```

