
# Request Status Enum

The current status of the callback response.

## Enumeration

`RequestStatusEnum`

## Fields

| Name |
|  --- |
| `Pending` |
| `Success` |
| `Failure` |

## Example

```
Success
```

