
# Firmware Type List Enum

Possible values are `append` or `remove`

## Enumeration

`FirmwareTypeListEnum`

## Fields

| Name |
|  --- |
| `Append` |
| `Remove` |

## Example

```
append
```

