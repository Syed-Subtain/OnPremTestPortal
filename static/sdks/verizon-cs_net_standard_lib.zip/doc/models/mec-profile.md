
# MEC Profile

## Structure

`MECProfile`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `ProfileId` | `string` | Optional | - |
| `ProfileName` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "profileId": "HSS-EsmProfile_Enterprise",
  "profileName": "HSS EsmProfile Enterprise"
}
```

