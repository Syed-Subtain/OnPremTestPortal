
# Callback Service Enum

Callback type. Must be 'Fota' for Software Management Services API.

## Enumeration

`CallbackServiceEnum`

## Fields

| Name |
|  --- |
| `Fota` |

## Example

```
Fota
```

