
# Billing Cycle

## Structure

`BillingCycle`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Year` | `string` | Optional | - |
| `Month` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "year": "2020",
  "month": "3"
}
```

