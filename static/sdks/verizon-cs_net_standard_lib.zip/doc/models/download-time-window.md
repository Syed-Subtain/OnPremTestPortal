
# Download Time Window

## Structure

`DownloadTimeWindow`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `StartTime` | `string` | Optional | Device IMEI list. |
| `EndTime` | `string` | Optional | Device IMEI list. |

## Example (as JSON)

```json
{
  "startTime": "0",
  "endTime": "0"
}
```

