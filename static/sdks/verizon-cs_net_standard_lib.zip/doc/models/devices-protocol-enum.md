
# Devices Protocol Enum

Firmware protocol. Valid values include: LWM2M, OMADM, HTTP.

## Enumeration

`DevicesProtocolEnum`

## Fields

| Name |
|  --- |
| `LWM2m` |
| `OMDADM` |
| `HTTP` |

## Example

```
LWM2M
```

