
# MEC Device Id

## Structure

`MECDeviceId`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Id` | `string` | Required | - |
| `Kind` | `string` | Required | - |

## Example (as JSON)

```json
{
  "id": "99948099913024600001",
  "kind": "iccid"
}
```

