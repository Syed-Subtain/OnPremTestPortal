
# Keysms Percentage 50

## Structure

`KeysmsPercentage50`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Key` | `string` | Optional | - |
| `MValue` | `bool?` | Optional | - |

## Example (as JSON)

```json
{
  "key": "SmsPercentage50",
  "value": false
}
```

