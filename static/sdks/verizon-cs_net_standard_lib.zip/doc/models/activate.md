
# Activate

## Structure

`Activate`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Profile` | `string` | Required | - |

## Example (as JSON)

```json
{
  "profile": "HSS EsmProfile Enterprise 5G"
}
```

