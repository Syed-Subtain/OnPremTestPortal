
# Configuration

List of the field names and values to set.

## Structure

`Configuration`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Frequency` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "frequency": "Low"
}
```

