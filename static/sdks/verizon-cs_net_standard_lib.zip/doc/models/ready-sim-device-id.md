
# Ready Sim Device Id

## Structure

`ReadySimDeviceId`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Kind` | `string` | Optional | - |
| `Id` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "kind": "iccid",
  "id": "20-digit iccid"
}
```

