
# Extended Attributes

Additional properties associated with data.

## Structure

`ExtendedAttributes`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Key` | `string` | Optional | - |
| `MValue` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "key": "key8",
  "value": "value0"
}
```

