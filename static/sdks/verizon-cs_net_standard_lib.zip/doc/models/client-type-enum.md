
# Client Type Enum

The category of application client.

## Enumeration

`ClientTypeEnum`

## Fields

| Name |
|  --- |
| `V2X` |
| `ComputerVision` |
| `MachineLearning` |
| `IoT` |
| `Gaming` |
| `AR` |
| `VR` |
| `Analytics` |
| `Robotics` |

