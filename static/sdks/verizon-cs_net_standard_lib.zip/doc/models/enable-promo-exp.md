
# Enable Promo Exp

## Structure

`EnablePromoExp`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `EnablePromoExp` | `bool?` | Optional | - |

## Example (as JSON)

```json
{
  "enablePromoExp": true
}
```

