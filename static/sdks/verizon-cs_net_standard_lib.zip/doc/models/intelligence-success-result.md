
# Intelligence Success Result

Success response.

## Structure

`IntelligenceSuccessResult`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Status` | `string` | Optional | Anomaly detection status. |

## Example (as JSON)

```json
{
  "status": "Success"
}
```

