
# Notification Report Status Request

## Structure

`NotificationReportStatusRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AccountName` | `string` | Optional | The name of a billing account. |
| `Device` | [`DeviceId`](../../doc/models/device-id.md) | Optional | An identifier for a single device. |
| `RequestExpirationTime` | `string` | Optional | The time at which the request expires. |
| `RequestType` | `string` | Optional | The type of request. |

## Example (as JSON)

```json
{
  "accountName": "0868924207-00001",
  "device": {
    "kind": "imei",
    "id": "990013907835573"
  },
  "requestExpirationTime": "requestExpirationTime6",
  "requestType": "requestType8"
}
```

