
# Carrier Activate Request

Request for carrier activation.

## Structure

`CarrierActivateRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `AccountName` | `string` | Optional | The name of a billing account. |
| `CarrierIpPoolName` | `string` | Optional | The private IP pool (Carrier Group Name) from which your device IP addresses will be derived. |
| `CarrierName` | `string` | Optional | The carrier that will perform the activation. |
| `CostCenterCode` | `string` | Optional | A string to identify the cost center that the device is associated with. |
| `CustomFields` | [`List<CustomFields>`](../../doc/models/custom-fields.md) | Optional | A user-defined descriptive field, limited to 50 characters. |
| `Devices` | [`List<AccountDeviceList>`](../../doc/models/account-device-list.md) | Optional | Up to 10,000 devices for which you want to activate service, specified by device identifier. |
| `GroupName` | `string` | Optional | If you specify devices by ID in the devices parameters, this is the name of a device group that the devices should be added to.If you don't specify individual devices with the devices parameter, you can provide the name of a device group to activate all devices in that group. |
| `LeadId` | `string` | Optional | The ID of a “Qualified” or “Closed - Won” VPP customer lead, which is used with other values to determine MDN assignment, taxation, and compensation. |
| `MdnZipCode` | `string` | Optional | The Zip code of the location where the line of service will primarily be used, or a Zip code that you have been told to use with these devices. For accounts that are configured for geographic numbering, this is the ZIP code from which the MDN will be derived. |
| `PrimaryPlaceOfUse` | [`PlaceOfUse`](../../doc/models/place-of-use.md) | Optional | The customer name and the address of the device's primary place of use. Leave these fields empty to use the account profile address as the primary place of use. These values will be applied to all devices in the request.If the account is enabled for non-geographic MDNs and the device supports it, the primaryPlaceOfUse address will also be used to derive the MDN for the device. |
| `PublicIpRestriction` | `string` | Optional | For devices with static IP addresses on the public network, this specifies whether the devices have general access to the Internet. |
| `ServicePlan` | `string` | Optional | The service plan code that you want to assign to all specified devices. |
| `SkuNumber` | `string` | Optional | The Stock Keeping Unit (SKU) of a 4G device type can be used with ICCID device identifiers in lieu of an IMEI when activating 4G devices. The SkuNumber will be used with all devices in the request, so all devices must be of the same type. |

## Example (as JSON)

```json
{
  "devices": [
    {
      "deviceIds": [
        {
          "kind": "imei",
          "id": "990013907835573"
        },
        {
          "kind": "iccid",
          "id": "89141390780800784259"
        }
      ]
    },
    {
      "deviceIds": [
        {
          "kind": "imei",
          "id": "990013907884259"
        },
        {
          "kind": "iccid",
          "id": "89141390780800735573"
        }
      ]
    }
  ],
  "accountName": "0868924207-00001",
  "servicePlan": "m2m_4G",
  "mdnZipCode": "98801",
  "customFields": [
    {
      "key": "CustomField2",
      "value": "SuperVend"
    }
  ],
  "groupName": "4G West",
  "primaryPlaceOfUse": {
    "customerName": {
      "title": "President",
      "firstName": "Zaffod",
      "lastName": "Beeblebrox"
    },
    "address": {
      "addressLine1": "1600 Pennsylvania Ave NW",
      "city": "Washington",
      "state": "DC",
      "zip": "20500",
      "country": "USA"
    }
  },
  "carrierIpPoolName": "carrierIpPoolName8",
  "carrierName": "carrierName2",
  "costCenterCode": "costCenterCode0"
}
```

