
# Key Service Plan

## Structure

`KeyServicePlan`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Key` | `string` | Optional | - |

## Example (as JSON)

```json
{
  "key": "ServicePlan"
}
```

