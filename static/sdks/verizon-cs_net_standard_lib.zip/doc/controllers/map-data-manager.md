# Map Data Manager

```csharp
MapDataManagerController mapDataManagerController = client.MapDataManagerController;
```

## Class Name

`MapDataManagerController`

## Methods

* [Upload Map Data Message](../../doc/controllers/map-data-manager.md#upload-map-data-message)
* [Download Map Data Message](../../doc/controllers/map-data-manager.md#download-map-data-message)


# Upload Map Data Message

This endpoint allows user to upload map messages in asn.1 J2735 encoded format. The MapData can have one or more intersections.

```csharp
UploadMapDataMessageAsync(
    string basicToken,
    string username,
    string password,
    string body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `basicToken` | `string` | Header, Required | This is the Basic (authentication) token for the user. It should be acquired by using the ThingSpace Portal (thingspace.verizon.com). |
| `username` | `string` | Header, Required | This is the UWS login name for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `password` | `string` | Header, Required | This is the UWS password for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `body` | `string` | Body, Required | - |

## Response Type

`Task<ApiResponse<string>>`

## Example Usage

```csharp
string basicToken = "RGFrb3RhQ2xpZWnTAtYjNhMjGyYWE0ZWMz";
string username = "VerizonImpUser";
string password = "Some-Password_123";
string body = "body6";
try
{
    ApiResponse<string> result = await mapDataManagerController.UploadMapDataMessageAsync(
        basicToken,
        username,
        password,
        body
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid request | [`MapDataResponseErrorException`](../../doc/models/map-data-response-error-exception.md) |
| 401 | Unauthorized | [`MapDataResponseErrorException`](../../doc/models/map-data-response-error-exception.md) |
| 403 | Forbidden Request | [`MapDataResponseErrorException`](../../doc/models/map-data-response-error-exception.md) |
| 429 | Too Many Requests | [`MapDataResponseErrorException`](../../doc/models/map-data-response-error-exception.md) |
| 503 | Internal server Error | [`MapDataResponseErrorException`](../../doc/models/map-data-response-error-exception.md) |
| Default | Forbidden | [`MapDataResponseErrorException`](../../doc/models/map-data-response-error-exception.md) |


# Download Map Data Message

This endpoint allows user to download SAE J2735 MAP messages in ASN.1 UPER format. The area for the MAP messages is needed to be defined in the query.

```csharp
DownloadMapDataMessageAsync(
    string basicToken,
    string username,
    string password,
    Models.Polygon geoFence)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `basicToken` | `string` | Header, Required | This is the Basic (authentication) token for the user. It should be acquired by using the ThingSpace Portal (thingspace.verizon.com). |
| `username` | `string` | Header, Required | This is the UWS login name for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `password` | `string` | Header, Required | This is the UWS password for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `geoFence` | [`Polygon`](../../doc/models/polygon.md) | Query, Required | - |

## Response Type

`Task<ApiResponse<string>>`

## Example Usage

```csharp
string basicToken = "RGFrb3RhQ2xpZWnTAtYjNhMjGyYWE0ZWMz";
string username = "Imp-Us3r@verizon.com";
string password = "Some-Password_123";
Polygon geoFence = new Polygon
{
    Type = "Polygon",
};

try
{
    ApiResponse<string> result = await mapDataManagerController.DownloadMapDataMessageAsync(
        basicToken,
        username,
        password,
        geoFence
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`MapDataResponseErrorException`](../../doc/models/map-data-response-error-exception.md) |
| 403 | Forbidden Request | [`MapDataResponseErrorException`](../../doc/models/map-data-response-error-exception.md) |
| 429 | Too Many Requests | [`MapDataResponseErrorException`](../../doc/models/map-data-response-error-exception.md) |
| 503 | Internal server Error | [`MapDataResponseErrorException`](../../doc/models/map-data-response-error-exception.md) |
| Default | Forbidden | [`MapDataResponseErrorException`](../../doc/models/map-data-response-error-exception.md) |

