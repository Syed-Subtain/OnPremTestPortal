# Registration

```csharp
RegistrationController registrationController = client.RegistrationController;
```

## Class Name

`RegistrationController`

## Methods

* [Register IMP Vendor](../../doc/controllers/registration.md#register-imp-vendor)
* [Unregister IMP Vendor](../../doc/controllers/registration.md#unregister-imp-vendor)
* [Register IMP Device](../../doc/controllers/registration.md#register-imp-device)
* [Unregister IMP Device](../../doc/controllers/registration.md#unregister-imp-device)
* [Retrieve MQT Turl](../../doc/controllers/registration.md#retrieve-mqt-turl)


# Register IMP Vendor

With this API call the users (clients) register themselves as Vendors to the IMP system. Therefore, when a registration is initiated from a device or software service to the IMP system with the registered VendorID, then the client registration will be authorized.

```csharp
RegisterIMPVendorAsync(
    string basicToken,
    string username,
    string password,
    Models.VendorRegistrationRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `basicToken` | `string` | Header, Required | This is the Basic (authentication) token for the user. It should be acquired by using the ThingSpace Portal (thingspace.verizon.com). |
| `username` | `string` | Header, Required | This is the UWS login name for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `password` | `string` | Header, Required | This is the UWS password for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `body` | [`VendorRegistrationRequest`](../../doc/models/vendor-registration-request.md) | Body, Required | - |

## Response Type

[`Task<ApiResponse<Models.VendorRegistrationResponse>>`](../../doc/models/vendor-registration-response.md)

## Example Usage

```csharp
string basicToken = "RGFrb3RhQ2xpZWnTAtYjNhMjGyYWE0ZWMz";
string username = "VerizonImpUser";
string password = "Some-Password_123";
VendorRegistrationRequest body = new VendorRegistrationRequest
{
    VendorID = "VerizonIMP",
    ThingSpaceBillingAccount = "0242080520-00001",
};

try
{
    ApiResponse<VendorRegistrationResponse> result = await registrationController.RegisterIMPVendorAsync(
        basicToken,
        username,
        password,
        body
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid Request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 401 | Unauthorized Request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 403 | Forbidden Request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 429 | Too Many Requests | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 503 | Internal Server Error | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| Default | Forbidden | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |


# Unregister IMP Vendor

With this API call the users (clients) can unregister themselves from the IMP system. The devices and services for this Vendor will no longer be able to use the IMP Message Exchange.

```csharp
UnregisterIMPVendorAsync(
    string basicToken,
    string username,
    string password,
    string vendorID)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `basicToken` | `string` | Header, Required | This is the Basic (authentication) token for the user. It should be acquired by using the ThingSpace Portal (thingspace.verizon.com). |
| `username` | `string` | Header, Required | This is the UWS login name for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `password` | `string` | Header, Required | This is the UWS password for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `vendorID` | `string` | Query, Required | The VendorID set during the Vendor registration call. |

## Response Type

`Task`

## Example Usage

```csharp
string basicToken = "RGFrb3RhQ2xpZWnTAtYjNhMjGyYWE0ZWMz";
string username = "VerizonImpUser";
string password = "Some-Password_123";
string vendorID = "VerizonIMP";
try
{
    await registrationController.UnregisterIMPVendorAsync(
        basicToken,
        username,
        password,
        vendorID
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid Request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 401 | Unauthorized Request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 403 | Forbidden Request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 429 | Too Many Requests | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 503 | Internal Server Error | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| Default | Forbidden | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |


# Register IMP Device

With this API call the user (client) registers its device or software service to the IMP system. Therefore, when a connection is initiated from the device or software service to the IMP system along with the credential provided by this registration call, then the connection will be authorized.
Note 1: One user can register multiple devices or software services, which can all be used at the same time.

Note 2: The user needs to authenticate with their ThingSpace credentials and request a bearer token in order to call this API.

```csharp
RegisterIMPDeviceAsync(
    string username,
    string password,
    Models.ClientRegistrationRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `username` | `string` | Header, Required | This is the UWS login name for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `password` | `string` | Header, Required | This is the UWS password for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `body` | [`ClientRegistrationRequest`](../../doc/models/client-registration-request.md) | Body, Required | - |

## Response Type

[`Task<ApiResponse<Models.ClientRegistrationResponse>>`](../../doc/models/client-registration-response.md)

## Example Usage

```csharp
string username = "VerizonImpUser";
string password = "Some-Password_123";
ClientRegistrationRequest body = new ClientRegistrationRequest
{
    ClientType = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
    ClientSubtype = ClientSubtypeEnum.MaintenanceVehicle,
    VendorID = "Verizon",
};

try
{
    ApiResponse<ClientRegistrationResponse> result = await registrationController.RegisterIMPDeviceAsync(
        username,
        password,
        body
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid Request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 401 | Unauthorized Request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 403 | Forbidden Request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 429 | Too Many Requests | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 503 | Internal Server Error | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| Default | Forbidden | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |


# Unregister IMP Device

With this API call the user (client) can unregister its devices and software services from the IMP system. The unregistered devices and services will no longer be able to use the IMP Message Exchange.

```csharp
UnregisterIMPDeviceAsync(
    string username,
    string password,
    List<Guid> deviceIDs)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `username` | `string` | Header, Required | This is the UWS login name for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `password` | `string` | Header, Required | This is the UWS password for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `deviceIDs` | `List<Guid>` | Query, Required | The Device IDs acquired through the registration API. |

## Response Type

`Task`

## Example Usage

```csharp
string username = "VerizonImpUser";
string password = "Some-Password_123";
List<Guid> deviceIDs = new List<Guid>
{
    new Guid("0000225a-0000-0000-0000-000000000000"),
};

try
{
    await registrationController.UnregisterIMPDeviceAsync(
        username,
        password,
        deviceIDs
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid Request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 401 | Unauthorized Request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 403 | Forbidden Request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 429 | Too Many Requests | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 503 | Internal Server Error | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| Default | Forbidden | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |


# Retrieve MQT Turl

With this API call the  or software service requests the MQTT URL for the location that it needs to connect. To determine the proper URL the device or software service needs to provide its ID (the one that was provided in the registration request), location (GPS coordinates), and whether it is on the Verizon cellular network or not.

Note: The user needs to authenticate with their ThingSpace credentials and request a bearer token in order to call this API.

```csharp
RetrieveMQTTurlAsync(
    string username,
    string password,
    string vendorID,
    Models.ConnectionRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `username` | `string` | Header, Required | This is the UWS login name for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `password` | `string` | Header, Required | This is the UWS password for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `vendorID` | `string` | Header, Required | The VendorID set during the Vendor registration call. |
| `body` | [`ConnectionRequest`](../../doc/models/connection-request.md) | Body, Required | - |

## Response Type

[`Task<ApiResponse<Models.ConnectionResponse>>`](../../doc/models/connection-response.md)

## Example Usage

```csharp
string username = "VerizonImpUser";
string password = "Some-Password_123";
string vendorID = "VerizonIMP";
ConnectionRequest body = new ConnectionRequest
{
    DeviceID = new Guid("976c4bad-03d3-4dcb-9688-ee57db7890e4"),
    Geolocation = new Geolocation
    {
        Latitude = 42.36,
        Longitude = -71.06,
    },
    NetworkType = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
};

try
{
    ApiResponse<ConnectionResponse> result = await registrationController.RetrieveMQTTurlAsync(
        username,
        password,
        vendorID,
        body
    );
}
catch (ApiException e)
{
    // TODO: Handle exception here
    Console.WriteLine(e.Message);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 401 | Unauthorized | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 403 | Forbidden Request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 429 | Too Many Requests | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 503 | Internal server Error | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| Default | Forbidden | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |

