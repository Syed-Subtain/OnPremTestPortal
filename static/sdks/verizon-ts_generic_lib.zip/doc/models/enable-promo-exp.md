
# Enable Promo Exp

## Structure

`EnablePromoExp`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `enablePromoExp` | `boolean \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "enablePromoExp": true
}
```

