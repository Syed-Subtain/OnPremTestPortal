
# Notification Report Status Request

## Structure

`NotificationReportStatusRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `accountName` | `string \| undefined` | Optional | The name of a billing account. |
| `device` | [`DeviceId \| undefined`](../../doc/models/device-id.md) | Optional | An identifier for a single device. |
| `requestExpirationTime` | `string \| undefined` | Optional | The time at which the request expires. |
| `requestType` | `string \| undefined` | Optional | The type of request. |

## Example (as JSON)

```json
{
  "accountName": "0868924207-00001",
  "device": {
    "kind": "imei",
    "id": "990013907835573"
  },
  "requestExpirationTime": "requestExpirationTime6",
  "requestType": "requestType8"
}
```

