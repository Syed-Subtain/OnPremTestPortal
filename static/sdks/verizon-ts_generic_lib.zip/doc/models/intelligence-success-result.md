
# Intelligence Success Result

Success response.

## Structure

`IntelligenceSuccessResult`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `status` | `string \| undefined` | Optional | Anomaly detection status. |

## Example (as JSON)

```json
{
  "status": "Success"
}
```

