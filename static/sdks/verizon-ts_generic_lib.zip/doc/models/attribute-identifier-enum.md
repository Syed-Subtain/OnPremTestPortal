
# Attribute Identifier Enum

Attribute identifier.

## Enumeration

`AttributeIdentifierEnum`

## Fields

| Name |
|  --- |
| `nETWORKBEARER` |
| `rADIOSIGNALSTRENGTH` |
| `lINKQUALITY` |
| `cELLID` |
| `mANUFACTURER` |

## Example

```
RADIO_SIGNAL_STRENGTH
```

