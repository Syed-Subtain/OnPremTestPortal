
# MEC Device Id

## Structure

`MECDeviceId`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `string` | Required | - |
| `kind` | `string` | Required | - |

## Example (as JSON)

```json
{
  "id": "99948099913024600001",
  "kind": "iccid"
}
```

