
# Billing Cycle

## Structure

`BillingCycle`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `year` | `string \| undefined` | Optional | - |
| `month` | `string \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "year": "2020",
  "month": "3"
}
```

