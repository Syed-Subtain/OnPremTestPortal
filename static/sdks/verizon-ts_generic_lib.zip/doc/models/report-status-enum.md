
# Report Status Enum

Status of the report.

## Enumeration

`ReportStatusEnum`

## Fields

| Name |
|  --- |
| `qUEUED` |
| `iNPROGRESS` |
| `cOMPLETED` |

## Example

```
INPROGRESS
```

