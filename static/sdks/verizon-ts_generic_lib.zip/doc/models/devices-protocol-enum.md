
# Devices Protocol Enum

Firmware protocol. Valid values include: LWM2M, OMADM, HTTP.

## Enumeration

`DevicesProtocolEnum`

## Fields

| Name |
|  --- |
| `lWM2m` |
| `oMDADM` |
| `hTTP` |

## Example

```
LWM2M
```

