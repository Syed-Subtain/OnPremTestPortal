
# Response Code Enum

Possible response codes.

## Enumeration

`ResponseCodeEnum`

## Fields

| Name |
|  --- |
| `iNVALIDACCESS` |
| `iNVALIDPARAMETER` |
| `iNTERNALERROR` |
| `sUCCESS` |

## Example

```
INVALID_ACCESS
```

