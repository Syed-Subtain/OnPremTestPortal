
# Enable Promo Exp 1

## Structure

`EnablePromoExp1`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `key` | `string \| undefined` | Optional | - |
| `value` | `boolean \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "key": "EnablePromoExp",
  "value": true
}
```

