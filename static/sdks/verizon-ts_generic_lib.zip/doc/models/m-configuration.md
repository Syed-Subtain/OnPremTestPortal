
# M Configuration

List of the field names and values to set.

## Structure

`MConfiguration`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `frequency` | `string \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "frequency": "Low"
}
```

