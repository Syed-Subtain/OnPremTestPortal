
# No of Days B4 Promo Exp

## Structure

`NoOfDaysB4PromoExp`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `key` | `string \| undefined` | Optional | - |
| `value` | `number \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "key": "NoOfDaysB4PromoExp",
  "value": 5
}
```

