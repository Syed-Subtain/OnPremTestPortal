
# Acceleration

## Structure

`Acceleration`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `x` | `string \| undefined` | Optional | - |
| `y` | `string \| undefined` | Optional | - |
| `z` | `string \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "x": "0.0277",
  "y": "-1.0334",
  "z": "-0.0134"
}
```

