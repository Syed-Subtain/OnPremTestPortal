
# Device Labels

A label for a single device.

## Structure

`DeviceLabels`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string \| undefined` | Optional | The label you want to associate with the device. |
| `value` | `string \| undefined` | Optional | The value of label |

## Example (as JSON)

```json
{
  "name": "VIN",
  "value": "XXUZL54B5YN105457"
}
```

