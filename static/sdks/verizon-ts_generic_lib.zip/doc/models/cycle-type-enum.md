
# Cycle Type Enum

## Enumeration

`CycleTypeEnum`

## Fields

| Name |
|  --- |
| `cycleone` |
| `cycletwo` |

