
# MEC Profile

## Structure

`MECProfile`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `profileId` | `string \| undefined` | Optional | - |
| `profileName` | `string \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "profileId": "HSS-EsmProfile_Enterprise",
  "profileName": "HSS EsmProfile Enterprise"
}
```

