
# Client Type Enum

The category of application client.

## Enumeration

`ClientTypeEnum`

## Fields

| Name |
|  --- |
| `v2X` |
| `computerVision` |
| `machineLearning` |
| `ioT` |
| `gaming` |
| `aR` |
| `vR` |
| `analytics` |
| `robotics` |

