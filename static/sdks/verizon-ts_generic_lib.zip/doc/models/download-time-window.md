
# Download Time Window

## Structure

`DownloadTimeWindow`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `startTime` | `string \| undefined` | Optional | Device IMEI list. |
| `endTime` | `string \| undefined` | Optional | Device IMEI list. |

## Example (as JSON)

```json
{
  "startTime": "0",
  "endTime": "0"
}
```

