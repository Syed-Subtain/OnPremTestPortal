
# Accuracy Mode Enum

Accurary, currently only 0-coarse supported.

## Enumeration

`AccuracyModeEnum`

## Fields

| Name |
|  --- |
| `enum0` |

## Example

```
0
```

