
# Extended Attributes

Additional properties associated with data.

## Structure

`ExtendedAttributes`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `key` | `string \| undefined` | Optional | - |
| `value` | `string \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "key": "key8",
  "value": "value0"
}
```

