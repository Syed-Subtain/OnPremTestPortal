
# Ready Sim Service Plan

## Structure

`ReadySimServicePlan`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `servicePlan` | `string \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "servicePlan": "123456"
}
```

