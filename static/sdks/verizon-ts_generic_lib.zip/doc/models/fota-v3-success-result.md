
# Fota V3 Success Result

Cancelation status.

## Structure

`FotaV3SuccessResult`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `success` | `boolean` | Required | True or false. |

## Example (as JSON)

```json
{
  "success": true
}
```

