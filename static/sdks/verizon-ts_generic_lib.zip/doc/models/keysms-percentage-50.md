
# Keysms Percentage 50

## Structure

`KeysmsPercentage50`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `key` | `string \| undefined` | Optional | - |
| `value` | `boolean \| undefined` | Optional | - |

## Example (as JSON)

```json
{
  "key": "SmsPercentage50",
  "value": false
}
```

