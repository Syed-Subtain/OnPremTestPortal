
# Error Response Code Enum

Error Code.

## Enumeration

`ErrorResponseCodeEnum`

## Fields

| Name |
|  --- |
| `iNVALIDACCESS` |
| `iNVALIDPARAMETER` |
| `iNTERNALERROR` |
| `sUCCESS` |

## Example

```
INVALID_ACCESS
```

