
# Connection Request

Request for /clients/connection. It requires the device ID acquired in the registration request call; the geolocation of the device at the time of the request; and the network type (Verizon or non-Verizon). The system uses this information to determine with MQTT endpoint the device should use to connect the IMP Message Exchange.

## Structure

`ConnectionRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `deviceID` | `string` | Required | The device ID acquired through the registration API. |
| `geolocation` | [`Geolocation`](../../doc/models/geolocation.md) | Required | Geolocation of the device at the time of the connection request in GPS coordinates. |
| `networkType` | `unknown` | Required | - |

## Example (as JSON)

```json
{
  "DeviceID": "976c4bad-03d3-4dcb-9688-ee57db7890e4",
  "Geolocation": {
    "Latitude": 42.36,
    "Longitude": -71.06
  },
  "NetworkType": {
    "key1": "val1",
    "key2": "val2"
  }
}
```

