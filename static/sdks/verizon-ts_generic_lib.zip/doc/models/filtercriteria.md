
# Filtercriteria

## Structure

`Filtercriteria`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `filterCriteria` | [`ReadySimServicePlan[] \| undefined`](../../doc/models/ready-sim-service-plan.md) | Optional | - |

## Example (as JSON)

```json
{
  "filterCriteria": [
    {
      "servicePlan": "servicePlan4"
    }
  ]
}
```

