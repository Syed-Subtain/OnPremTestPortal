
# Client Subtype Enum

The subtype or subgroup of the client type. This further specifies the client type. For example it will specify if the client is a passenger car or a truck. See the ClientType description for the supported Subtypes for each client type.

## Enumeration

`ClientSubtypeEnum`

## Fields

| Name |
|  --- |
| `passengerCar` |
| `truck` |
| `bus` |
| `emergencyVehicle` |
| `schoolBus` |
| `maintenanceVehicle` |
| `pedestrian` |
| `bicycle` |
| `scooter` |
| `motorcycle` |
| `roadSideUnit` |
| `camera` |
| `lidar` |
| `radar` |
| `inductiveLoop` |
| `magneticSensor` |
| `nA` |

