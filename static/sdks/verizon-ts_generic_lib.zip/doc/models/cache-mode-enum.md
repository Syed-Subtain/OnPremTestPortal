
# Cache Mode Enum

Location cache mode.

## Enumeration

`CacheModeEnum`

## Fields

| Name |
|  --- |
| `enum0` |
| `enum1` |
| `enum2` |

## Example

```
1
```

