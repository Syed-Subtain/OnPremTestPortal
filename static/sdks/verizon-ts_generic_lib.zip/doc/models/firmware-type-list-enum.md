
# Firmware Type List Enum

Possible values are `append` or `remove`

## Enumeration

`FirmwareTypeListEnum`

## Fields

| Name |
|  --- |
| `append` |
| `remove` |

## Example

```
append
```

