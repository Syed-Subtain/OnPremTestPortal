
# Firmware Protocol Enum

Firmware protocol. Valid values include: LWM2M, OMD-DM, all.

## Enumeration

`FirmwareProtocolEnum`

## Fields

| Name |
|  --- |
| `lWM2m` |
| `oMDDM` |
| `all` |

## Example

```
LWM2M
```

