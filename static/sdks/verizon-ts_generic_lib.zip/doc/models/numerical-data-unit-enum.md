
# Numerical Data Unit Enum

Unit of time.

## Enumeration

`NumericalDataUnitEnum`

## Fields

| Name |
|  --- |
| `sECOND` |
| `mINUTE` |
| `hOUR` |
| `dAY` |

## Example

```
MINUTE
```

