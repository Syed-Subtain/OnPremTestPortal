
# Callback Service Name Enum

The name of the callback service.

## Enumeration

`CallbackServiceNameEnum`

## Fields

| Name |
|  --- |
| `location` |
| `deviceLocation` |

## Example

```
Location
```

