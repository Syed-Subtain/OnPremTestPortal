# Map Data Manager

```ts
const mapDataManagerController = new MapDataManagerController(client);
```

## Class Name

`MapDataManagerController`

## Methods

* [Upload Map Data Message](../../doc/controllers/map-data-manager.md#upload-map-data-message)
* [Download Map Data Message](../../doc/controllers/map-data-manager.md#download-map-data-message)


# Upload Map Data Message

This endpoint allows user to upload map messages in asn.1 J2735 encoded format. The MapData can have one or more intersections.

```ts
async uploadMapDataMessage(
  basicToken: string,
  username: string,
  password: string,
  body: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<string>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `basicToken` | `string` | Header, Required | This is the Basic (authentication) token for the user. It should be acquired by using the ThingSpace Portal (thingspace.verizon.com). |
| `username` | `string` | Header, Required | This is the UWS login name for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `password` | `string` | Header, Required | This is the UWS password for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `body` | `string` | Body, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`string`

## Example Usage

```ts
const basicToken = 'RGFrb3RhQ2xpZWnTAtYjNhMjGyYWE0ZWMz';

const username = 'VerizonImpUser';

const password = 'Some-Password_123';

const body = 'body6';

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await mapDataManagerController.uploadMapDataMessage(
  basicToken,
  username,
  password,
  body
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid request | [`MapDataResponseError`](../../doc/models/map-data-response-error.md) |
| 401 | Unauthorized | [`MapDataResponseError`](../../doc/models/map-data-response-error.md) |
| 403 | Forbidden Request | [`MapDataResponseError`](../../doc/models/map-data-response-error.md) |
| 429 | Too Many Requests | [`MapDataResponseError`](../../doc/models/map-data-response-error.md) |
| 503 | Internal server Error | [`MapDataResponseError`](../../doc/models/map-data-response-error.md) |
| Default | Forbidden | [`MapDataResponseError`](../../doc/models/map-data-response-error.md) |


# Download Map Data Message

This endpoint allows user to download SAE J2735 MAP messages in ASN.1 UPER format. The area for the MAP messages is needed to be defined in the query.

```ts
async downloadMapDataMessage(
  basicToken: string,
  username: string,
  password: string,
  geoFence: Polygon,
  requestOptions?: RequestOptions
): Promise<ApiResponse<string>>
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `basicToken` | `string` | Header, Required | This is the Basic (authentication) token for the user. It should be acquired by using the ThingSpace Portal (thingspace.verizon.com). |
| `username` | `string` | Header, Required | This is the UWS login name for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `password` | `string` | Header, Required | This is the UWS password for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `geoFence` | [`Polygon`](../../doc/models/polygon.md) | Query, Required | - |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

`string`

## Example Usage

```ts
const basicToken = 'RGFrb3RhQ2xpZWnTAtYjNhMjGyYWE0ZWMz';

const username = 'Imp-Us3r@verizon.com';

const password = 'Some-Password_123';

const geoFence: Polygon = {
  type: 'Polygon',
};

try {
  // @ts-expect-error: unused variables
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { result, ...httpResponse } = await mapDataManagerController.downloadMapDataMessage(
  basicToken,
  username,
  password,
  geoFence
);
  // Get more response info...
  // const { statusCode, headers } = httpResponse;
} catch (error) {
  if (error instanceof ApiError) {
    // @ts-expect-error: unused variables
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const errors = error.result;
    // const { statusCode, headers } = error;
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`MapDataResponseError`](../../doc/models/map-data-response-error.md) |
| 403 | Forbidden Request | [`MapDataResponseError`](../../doc/models/map-data-response-error.md) |
| 429 | Too Many Requests | [`MapDataResponseError`](../../doc/models/map-data-response-error.md) |
| 503 | Internal server Error | [`MapDataResponseError`](../../doc/models/map-data-response-error.md) |
| Default | Forbidden | [`MapDataResponseError`](../../doc/models/map-data-response-error.md) |

