# Registration

```python
registration_controller = client.registration
```

## Class Name

`RegistrationController`

## Methods

* [Register IMP Vendor](../../doc/controllers/registration.md#register-imp-vendor)
* [Unregister IMP Vendor](../../doc/controllers/registration.md#unregister-imp-vendor)
* [Register IMP Device](../../doc/controllers/registration.md#register-imp-device)
* [Unregister IMP Device](../../doc/controllers/registration.md#unregister-imp-device)
* [Retrieve MQT Turl](../../doc/controllers/registration.md#retrieve-mqt-turl)


# Register IMP Vendor

With this API call the users (clients) register themselves as Vendors to the IMP system. Therefore, when a registration is initiated from a device or software service to the IMP system with the registered VendorID, then the client registration will be authorized.

```python
def register_imp_vendor(self,
                       basic_token,
                       username,
                       password,
                       body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `basic_token` | `str` | Header, Required | This is the Basic (authentication) token for the user. It should be acquired by using the ThingSpace Portal (thingspace.verizon.com). |
| `username` | `str` | Header, Required | This is the UWS login name for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `password` | `str` | Header, Required | This is the UWS password for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `body` | [`VendorRegistrationRequest`](../../doc/models/vendor-registration-request.md) | Body, Required | - |

## Response Type

This method returns a `ApiResponse` instance. The `body` property of this instance returns the response data which is of type [`VendorRegistrationResponse`](../../doc/models/vendor-registration-response.md).

## Example Usage

```python
basic_token = 'RGFrb3RhQ2xpZWnTAtYjNhMjGyYWE0ZWMz'

username = 'VerizonImpUser'

password = 'Some-Password_123'

body = VendorRegistrationRequest(
    vendor_id='VerizonIMP',
    thing_space_billing_account='0242080520-00001'
)

result = registration_controller.register_imp_vendor(
    basic_token,
    username,
    password,
    body
)
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid Request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 401 | Unauthorized Request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 403 | Forbidden Request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 429 | Too Many Requests | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 503 | Internal Server Error | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| Default | Forbidden | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |


# Unregister IMP Vendor

With this API call the users (clients) can unregister themselves from the IMP system. The devices and services for this Vendor will no longer be able to use the IMP Message Exchange.

```python
def unregister_imp_vendor(self,
                         basic_token,
                         username,
                         password,
                         vendor_id)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `basic_token` | `str` | Header, Required | This is the Basic (authentication) token for the user. It should be acquired by using the ThingSpace Portal (thingspace.verizon.com). |
| `username` | `str` | Header, Required | This is the UWS login name for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `password` | `str` | Header, Required | This is the UWS password for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `vendor_id` | `str` | Query, Required | The VendorID set during the Vendor registration call. |

## Response Type

This method returns a `ApiResponse` instance.

## Example Usage

```python
basic_token = 'RGFrb3RhQ2xpZWnTAtYjNhMjGyYWE0ZWMz'

username = 'VerizonImpUser'

password = 'Some-Password_123'

vendor_id = 'VerizonIMP'

result = registration_controller.unregister_imp_vendor(
    basic_token,
    username,
    password,
    vendor_id
)
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid Request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 401 | Unauthorized Request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 403 | Forbidden Request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 429 | Too Many Requests | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 503 | Internal Server Error | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| Default | Forbidden | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |


# Register IMP Device

With this API call the user (client) registers its device or software service to the IMP system. Therefore, when a connection is initiated from the device or software service to the IMP system along with the credential provided by this registration call, then the connection will be authorized.
Note 1: One user can register multiple devices or software services, which can all be used at the same time.

Note 2: The user needs to authenticate with their ThingSpace credentials and request a bearer token in order to call this API.

```python
def register_imp_device(self,
                       username,
                       password,
                       body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `username` | `str` | Header, Required | This is the UWS login name for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `password` | `str` | Header, Required | This is the UWS password for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `body` | [`ClientRegistrationRequest`](../../doc/models/client-registration-request.md) | Body, Required | - |

## Response Type

This method returns a `ApiResponse` instance. The `body` property of this instance returns the response data which is of type [`ClientRegistrationResponse`](../../doc/models/client-registration-response.md).

## Example Usage

```python
username = 'VerizonImpUser'

password = 'Some-Password_123'

body = ClientRegistrationRequest(
    client_type=jsonpickle.decode('{"key1":"val1","key2":"val2"}'),
    client_subtype=ClientSubtypeEnum.MAINTENANCEVEHICLE,
    vendor_id='Verizon'
)

result = registration_controller.register_imp_device(
    username,
    password,
    body
)
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid Request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 401 | Unauthorized Request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 403 | Forbidden Request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 429 | Too Many Requests | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 503 | Internal Server Error | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| Default | Forbidden | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |


# Unregister IMP Device

With this API call the user (client) can unregister its devices and software services from the IMP system. The unregistered devices and services will no longer be able to use the IMP Message Exchange.

```python
def unregister_imp_device(self,
                         username,
                         password,
                         device_i_ds)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `username` | `str` | Header, Required | This is the UWS login name for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `password` | `str` | Header, Required | This is the UWS password for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `device_i_ds` | `List[uuid\|str]` | Query, Required | The Device IDs acquired through the registration API. |

## Response Type

This method returns a `ApiResponse` instance.

## Example Usage

```python
username = 'VerizonImpUser'

password = 'Some-Password_123'

device_i_ds = [
    '0000225a-0000-0000-0000-000000000000'
]

result = registration_controller.unregister_imp_device(
    username,
    password,
    device_i_ds
)
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid Request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 401 | Unauthorized Request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 403 | Forbidden Request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 429 | Too Many Requests | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 503 | Internal Server Error | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| Default | Forbidden | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |


# Retrieve MQT Turl

With this API call the  or software service requests the MQTT URL for the location that it needs to connect. To determine the proper URL the device or software service needs to provide its ID (the one that was provided in the registration request), location (GPS coordinates), and whether it is on the Verizon cellular network or not.

Note: The user needs to authenticate with their ThingSpace credentials and request a bearer token in order to call this API.

```python
def retrieve_mqt_turl(self,
                     username,
                     password,
                     vendor_id,
                     body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `username` | `str` | Header, Required | This is the UWS login name for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `password` | `str` | Header, Required | This is the UWS password for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `vendor_id` | `str` | Header, Required | The VendorID set during the Vendor registration call. |
| `body` | [`ConnectionRequest`](../../doc/models/connection-request.md) | Body, Required | - |

## Response Type

This method returns a `ApiResponse` instance. The `body` property of this instance returns the response data which is of type [`ConnectionResponse`](../../doc/models/connection-response.md).

## Example Usage

```python
username = 'VerizonImpUser'

password = 'Some-Password_123'

vendor_id = 'VerizonIMP'

body = ConnectionRequest(
    device_id='976c4bad-03d3-4dcb-9688-ee57db7890e4',
    geolocation=Geolocation(
        latitude=42.36,
        longitude=-71.06
    ),
    network_type=jsonpickle.decode('{"key1":"val1","key2":"val2"}')
)

result = registration_controller.retrieve_mqt_turl(
    username,
    password,
    vendor_id,
    body
)
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 401 | Unauthorized | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 403 | Forbidden Request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 429 | Too Many Requests | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 503 | Internal server Error | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| Default | Forbidden | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |

