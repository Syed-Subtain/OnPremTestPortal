# Map Data Manager

```python
map_data_manager_controller = client.map_data_manager
```

## Class Name

`MapDataManagerController`

## Methods

* [Upload Map Data Message](../../doc/controllers/map-data-manager.md#upload-map-data-message)
* [Download Map Data Message](../../doc/controllers/map-data-manager.md#download-map-data-message)


# Upload Map Data Message

This endpoint allows user to upload map messages in asn.1 J2735 encoded format. The MapData can have one or more intersections.

```python
def upload_map_data_message(self,
                           basic_token,
                           username,
                           password,
                           body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `basic_token` | `str` | Header, Required | This is the Basic (authentication) token for the user. It should be acquired by using the ThingSpace Portal (thingspace.verizon.com). |
| `username` | `str` | Header, Required | This is the UWS login name for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `password` | `str` | Header, Required | This is the UWS password for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `body` | `str` | Body, Required | - |

## Response Type

This method returns a `ApiResponse` instance. The `body` property of this instance returns the response data which is of type `str`.

## Example Usage

```python
basic_token = 'RGFrb3RhQ2xpZWnTAtYjNhMjGyYWE0ZWMz'

username = 'VerizonImpUser'

password = 'Some-Password_123'

body = 'body6'

result = map_data_manager_controller.upload_map_data_message(
    basic_token,
    username,
    password,
    body
)
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid request | [`MapDataResponseErrorException`](../../doc/models/map-data-response-error-exception.md) |
| 401 | Unauthorized | [`MapDataResponseErrorException`](../../doc/models/map-data-response-error-exception.md) |
| 403 | Forbidden Request | [`MapDataResponseErrorException`](../../doc/models/map-data-response-error-exception.md) |
| 429 | Too Many Requests | [`MapDataResponseErrorException`](../../doc/models/map-data-response-error-exception.md) |
| 503 | Internal server Error | [`MapDataResponseErrorException`](../../doc/models/map-data-response-error-exception.md) |
| Default | Forbidden | [`MapDataResponseErrorException`](../../doc/models/map-data-response-error-exception.md) |


# Download Map Data Message

This endpoint allows user to download SAE J2735 MAP messages in ASN.1 UPER format. The area for the MAP messages is needed to be defined in the query.

```python
def download_map_data_message(self,
                             basic_token,
                             username,
                             password,
                             geo_fence)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `basic_token` | `str` | Header, Required | This is the Basic (authentication) token for the user. It should be acquired by using the ThingSpace Portal (thingspace.verizon.com). |
| `username` | `str` | Header, Required | This is the UWS login name for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `password` | `str` | Header, Required | This is the UWS password for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `geo_fence` | [`Polygon`](../../doc/models/polygon.md) | Query, Required | - |

## Response Type

This method returns a `ApiResponse` instance. The `body` property of this instance returns the response data which is of type `str`.

## Example Usage

```python
basic_token = 'RGFrb3RhQ2xpZWnTAtYjNhMjGyYWE0ZWMz'

username = 'Imp-Us3r@verizon.com'

password = 'Some-Password_123'

geo_fence = Polygon(
    mtype='Polygon'
)

result = map_data_manager_controller.download_map_data_message(
    basic_token,
    username,
    password,
    geo_fence
)
print(result)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`MapDataResponseErrorException`](../../doc/models/map-data-response-error-exception.md) |
| 403 | Forbidden Request | [`MapDataResponseErrorException`](../../doc/models/map-data-response-error-exception.md) |
| 429 | Too Many Requests | [`MapDataResponseErrorException`](../../doc/models/map-data-response-error-exception.md) |
| 503 | Internal server Error | [`MapDataResponseErrorException`](../../doc/models/map-data-response-error-exception.md) |
| Default | Forbidden | [`MapDataResponseErrorException`](../../doc/models/map-data-response-error-exception.md) |

