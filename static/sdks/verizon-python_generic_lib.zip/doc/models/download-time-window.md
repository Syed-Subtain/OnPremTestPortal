
# Download Time Window

## Structure

`DownloadTimeWindow`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `start_time` | `str` | Optional | Device IMEI list. |
| `end_time` | `str` | Optional | Device IMEI list. |

## Example (as JSON)

```json
{
  "startTime": "0",
  "endTime": "0"
}
```

