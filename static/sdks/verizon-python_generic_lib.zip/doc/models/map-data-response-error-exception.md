
# Map Data Response Error Exception

error response structure

## Structure

`MapDataResponseErrorException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error` | `str` | Required | The short summary of the error<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `1024`, *Pattern*: `^[a-zA-Z0-9~\+\-!@#$%^&*()\`\[\]{=};"'':,.\/<>?\|\s]+$` |
| `description` | `str` | Required | The detailed description of the error<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `4096`, *Pattern*: `^[a-zA-Z0-9~\+\-!@#$%^&*()\`\[\]{=};"'':,.\/<>?\|\s]+$` |

## Example (as JSON)

```json
{
  "error": "Error Summary",
  "description": "Error Description"
}
```

