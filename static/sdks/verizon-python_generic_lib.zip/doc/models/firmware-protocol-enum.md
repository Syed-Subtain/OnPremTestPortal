
# Firmware Protocol Enum

Firmware protocol. Valid values include: LWM2M, OMD-DM, all.

## Enumeration

`FirmwareProtocolEnum`

## Fields

| Name |
|  --- |
| `LW_M2M` |
| `OMDDM` |
| `ALL` |

## Example

```
LWM2M
```

