
# Get MEC Performance Consent Response

MEC Performance Consent Response

## Structure

`GetMECPerformanceConsentResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `consent` | `str` | Optional | MEC Performance Consent Response. |

## Example (as JSON)

```json
{
  "consent": "false"
}
```

