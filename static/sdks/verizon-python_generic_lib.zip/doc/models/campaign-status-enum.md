
# Campaign Status Enum

Current status of the campaign.

## Enumeration

`CampaignStatusEnum`

## Fields

| Name |
|  --- |
| `CAMPAIGNREQUESTPENDING` |
| `CAMPAIGNREQUESTFAILED` |
| `CAMPAIGNREQUESTQUEUED` |
| `CAMPAIGNCANCELLED` |
| `CAMPAIGNABORTED` |
| `CAMPAIGNFAILED` |
| `CAMPAIGNSCHEDULED` |
| `CAMPAIGNENDED` |

## Example

```
CampaignRequestPending
```

