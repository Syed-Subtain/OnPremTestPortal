
# Ready Sim Device Id

## Structure

`ReadySimDeviceId`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `kind` | `str` | Optional | - |
| `id` | `str` | Optional | - |

## Example (as JSON)

```json
{
  "kind": "iccid",
  "id": "20-digit iccid"
}
```

