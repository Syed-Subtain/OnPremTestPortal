
# Configuration

List of the field names and values to set.

## Structure

`Configuration`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `frequency` | `str` | Optional | - |

## Example (as JSON)

```json
{
  "frequency": "Low"
}
```

