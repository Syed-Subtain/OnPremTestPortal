
# Device Propertylocation

## Structure

`DevicePropertylocation`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `latitude` | `str` | Optional | - |
| `longitude` | `str` | Optional | - |

## Example (as JSON)

```json
{
  "latitude": "37.2314796",
  "longitude": "-119.4692153"
}
```

