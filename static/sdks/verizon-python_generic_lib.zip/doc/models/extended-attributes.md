
# Extended Attributes

Additional properties associated with data.

## Structure

`ExtendedAttributes`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `key` | `str` | Optional | - |
| `value` | `str` | Optional | - |

## Example (as JSON)

```json
{
  "key": "key8",
  "value": "value0"
}
```

