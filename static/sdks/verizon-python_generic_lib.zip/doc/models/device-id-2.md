
# Device Id 2

## Structure

`DeviceId2`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `str` | Optional | - |
| `kind` | `str` | Optional | - |

## Example (as JSON)

```json
{
  "id": "15-digit IMEI",
  "kind": "imei"
}
```

