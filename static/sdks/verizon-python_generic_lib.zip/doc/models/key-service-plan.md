
# Key Service Plan

## Structure

`KeyServicePlan`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `key` | `str` | Optional | - |

## Example (as JSON)

```json
{
  "key": "ServicePlan"
}
```

