
# Device Location Success Result

Whether the device location request was successful or not.

## Structure

`DeviceLocationSuccessResult`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `success` | `bool` | Optional | - |

## Example (as JSON)

```json
{
  "success": true
}
```

