
# MEC Device Id

## Structure

`MECDeviceId`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `str` | Required | - |
| `kind` | `str` | Required | - |

## Example (as JSON)

```json
{
  "id": "99948099913024600001",
  "kind": "iccid"
}
```

