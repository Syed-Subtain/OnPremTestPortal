
# Devices Protocol Enum

Firmware protocol. Valid values include: LWM2M, OMADM, HTTP.

## Enumeration

`DevicesProtocolEnum`

## Fields

| Name |
|  --- |
| `LW_M2M` |
| `OMDADM` |
| `HTTP` |

## Example

```
LWM2M
```

