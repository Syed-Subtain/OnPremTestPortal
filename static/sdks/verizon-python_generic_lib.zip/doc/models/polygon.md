
# Polygon

## Structure

`Polygon`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `mtype` | `str` | Optional | **Constraints**: *Maximum Length*: `10`, *Pattern*: `^[a-zA-Z0-9]*$` |
| `coordinates` | [`List[Coordinate]`](../../doc/models/coordinate.md) | Optional | **Constraints**: *Maximum Items*: `20` |

## Example (as JSON)

```json
{
  "type": "Polygon",
  "coordinates": [
    {
      "latitude": "latitude4",
      "longitude": "longitude4"
    }
  ]
}
```

