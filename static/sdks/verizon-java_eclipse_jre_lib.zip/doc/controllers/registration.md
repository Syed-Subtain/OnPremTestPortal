# Registration

```java
RegistrationController registrationController = client.getRegistrationController();
```

## Class Name

`RegistrationController`

## Methods

* [Register IMP Vendor](../../doc/controllers/registration.md#register-imp-vendor)
* [Unregister IMP Vendor](../../doc/controllers/registration.md#unregister-imp-vendor)
* [Register IMP Device](../../doc/controllers/registration.md#register-imp-device)
* [Unregister IMP Device](../../doc/controllers/registration.md#unregister-imp-device)
* [Retrieve MQT Turl](../../doc/controllers/registration.md#retrieve-mqt-turl)


# Register IMP Vendor

With this API call the users (clients) register themselves as Vendors to the IMP system. Therefore, when a registration is initiated from a device or software service to the IMP system with the registered VendorID, then the client registration will be authorized.

```java
CompletableFuture<ApiResponse<VendorRegistrationResponse>> registerIMPVendorAsync(
    final String basicToken,
    final String username,
    final String password,
    final VendorRegistrationRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `basicToken` | `String` | Header, Required | This is the Basic (authentication) token for the user. It should be acquired by using the ThingSpace Portal (thingspace.verizon.com). |
| `username` | `String` | Header, Required | This is the UWS login name for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `password` | `String` | Header, Required | This is the UWS password for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `body` | [`VendorRegistrationRequest`](../../doc/models/vendor-registration-request.md) | Body, Required | - |

## Server

`Server.IMP_SERVER`

## Response Type

[`VendorRegistrationResponse`](../../doc/models/vendor-registration-response.md)

## Example Usage

```java
String basicToken = "RGFrb3RhQ2xpZWnTAtYjNhMjGyYWE0ZWMz";
String username = "VerizonImpUser";
String password = "Some-Password_123";
VendorRegistrationRequest body = new VendorRegistrationRequest.Builder(
    "VerizonIMP",
    "0242080520-00001"
)
.build();

registrationController.registerIMPVendorAsync(basicToken, username, password, body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid Request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 401 | Unauthorized Request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 403 | Forbidden Request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 429 | Too Many Requests | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 503 | Internal Server Error | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| Default | Forbidden | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |


# Unregister IMP Vendor

With this API call the users (clients) can unregister themselves from the IMP system. The devices and services for this Vendor will no longer be able to use the IMP Message Exchange.

```java
CompletableFuture<ApiResponse<Void>> unregisterIMPVendorAsync(
    final String basicToken,
    final String username,
    final String password,
    final String vendorID)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `basicToken` | `String` | Header, Required | This is the Basic (authentication) token for the user. It should be acquired by using the ThingSpace Portal (thingspace.verizon.com). |
| `username` | `String` | Header, Required | This is the UWS login name for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `password` | `String` | Header, Required | This is the UWS password for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `vendorID` | `String` | Query, Required | The VendorID set during the Vendor registration call. |

## Server

`Server.IMP_SERVER`

## Response Type

`void`

## Example Usage

```java
String basicToken = "RGFrb3RhQ2xpZWnTAtYjNhMjGyYWE0ZWMz";
String username = "VerizonImpUser";
String password = "Some-Password_123";
String vendorID = "VerizonIMP";

registrationController.unregisterIMPVendorAsync(basicToken, username, password, vendorID).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid Request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 401 | Unauthorized Request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 403 | Forbidden Request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 429 | Too Many Requests | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 503 | Internal Server Error | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| Default | Forbidden | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |


# Register IMP Device

With this API call the user (client) registers its device or software service to the IMP system. Therefore, when a connection is initiated from the device or software service to the IMP system along with the credential provided by this registration call, then the connection will be authorized.
Note 1: One user can register multiple devices or software services, which can all be used at the same time.

Note 2: The user needs to authenticate with their ThingSpace credentials and request a bearer token in order to call this API.

```java
CompletableFuture<ApiResponse<ClientRegistrationResponse>> registerIMPDeviceAsync(
    final String username,
    final String password,
    final ClientRegistrationRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `username` | `String` | Header, Required | This is the UWS login name for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `password` | `String` | Header, Required | This is the UWS password for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `body` | [`ClientRegistrationRequest`](../../doc/models/client-registration-request.md) | Body, Required | - |

## Server

`Server.IMP_SERVER`

## Response Type

[`ClientRegistrationResponse`](../../doc/models/client-registration-response.md)

## Example Usage

```java
String username = "VerizonImpUser";
String password = "Some-Password_123";
ClientRegistrationRequest body = new ClientRegistrationRequest.Builder(
    ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
    ClientSubtypeEnum.MAINTENANCEVEHICLE,
    "Verizon"
)
.build();

registrationController.registerIMPDeviceAsync(username, password, body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid Request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 401 | Unauthorized Request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 403 | Forbidden Request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 429 | Too Many Requests | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 503 | Internal Server Error | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| Default | Forbidden | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |


# Unregister IMP Device

With this API call the user (client) can unregister its devices and software services from the IMP system. The unregistered devices and services will no longer be able to use the IMP Message Exchange.

```java
CompletableFuture<ApiResponse<Void>> unregisterIMPDeviceAsync(
    final String username,
    final String password,
    final List<UUID> deviceIDs)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `username` | `String` | Header, Required | This is the UWS login name for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `password` | `String` | Header, Required | This is the UWS password for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `deviceIDs` | `List<UUID>` | Query, Required | The Device IDs acquired through the registration API. |

## Server

`Server.IMP_SERVER`

## Response Type

`void`

## Example Usage

```java
String username = "VerizonImpUser";
String password = "Some-Password_123";
List<UUID> deviceIDs = Arrays.asList(
    UUID.fromString("0000225a-0000-0000-0000-000000000000")
);

registrationController.unregisterIMPDeviceAsync(username, password, deviceIDs).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid Request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 401 | Unauthorized Request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 403 | Forbidden Request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 429 | Too Many Requests | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 503 | Internal Server Error | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| Default | Forbidden | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |


# Retrieve MQT Turl

With this API call the  or software service requests the MQTT URL for the location that it needs to connect. To determine the proper URL the device or software service needs to provide its ID (the one that was provided in the registration request), location (GPS coordinates), and whether it is on the Verizon cellular network or not.

Note: The user needs to authenticate with their ThingSpace credentials and request a bearer token in order to call this API.

```java
CompletableFuture<ApiResponse<ConnectionResponse>> retrieveMQTTurlAsync(
    final String username,
    final String password,
    final String vendorID,
    final ConnectionRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `username` | `String` | Header, Required | This is the UWS login name for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `password` | `String` | Header, Required | This is the UWS password for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `vendorID` | `String` | Header, Required | The VendorID set during the Vendor registration call. |
| `body` | [`ConnectionRequest`](../../doc/models/connection-request.md) | Body, Required | - |

## Server

`Server.IMP_SERVER`

## Response Type

[`ConnectionResponse`](../../doc/models/connection-response.md)

## Example Usage

```java
String username = "VerizonImpUser";
String password = "Some-Password_123";
String vendorID = "VerizonIMP";
ConnectionRequest body = new ConnectionRequest.Builder(
    UUID.fromString("976c4bad-03d3-4dcb-9688-ee57db7890e4"),
    new Geolocation.Builder(
        42.36D,
        -71.06D
    )
    .build(),
    ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}")
)
.build();

registrationController.retrieveMQTTurlAsync(username, password, vendorID, body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    // TODO failure callback handler
    exception.printStackTrace();
    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 401 | Unauthorized | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 403 | Forbidden Request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 429 | Too Many Requests | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 503 | Internal server Error | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| Default | Forbidden | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |

