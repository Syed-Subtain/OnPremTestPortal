
# Get MEC Performance Consent Response

MEC Performance Consent Response

## Structure

`GetMECPerformanceConsentResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Consent` | `String` | Optional | MEC Performance Consent Response. | String getConsent() | setConsent(String consent) |

## Example (as JSON)

```json
{
  "consent": "false"
}
```

