
# Fota V2 Success Result

Response to a successful request.

## Structure

`FotaV2SuccessResult`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Success` | `boolean` | Required | - | boolean getSuccess() | setSuccess(boolean success) |

## Example (as JSON)

```json
{
  "success": true
}
```

