
# Report Status Enum

Status of the report.

## Enumeration

`ReportStatusEnum`

## Fields

| Name |
|  --- |
| `QUEUED` |
| `INPROGRESS` |
| `COMPLETED` |

## Example

```
INPROGRESS
```

