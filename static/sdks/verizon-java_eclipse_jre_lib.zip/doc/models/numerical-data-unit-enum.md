
# Numerical Data Unit Enum

Unit of time.

## Enumeration

`NumericalDataUnitEnum`

## Fields

| Name |
|  --- |
| `SECOND` |
| `MINUTE` |
| `HOUR` |
| `DAY` |

## Example

```
MINUTE
```

