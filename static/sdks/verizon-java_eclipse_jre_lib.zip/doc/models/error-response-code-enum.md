
# Error Response Code Enum

Error Code.

## Enumeration

`ErrorResponseCodeEnum`

## Fields

| Name |
|  --- |
| `INVALIDACCESS` |
| `INVALIDPARAMETER` |
| `INTERNALERROR` |
| `SUCCESS` |

## Example

```
INVALID_ACCESS
```

