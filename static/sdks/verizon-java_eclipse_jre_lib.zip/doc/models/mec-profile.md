
# MEC Profile

## Structure

`MECProfile`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ProfileId` | `String` | Optional | - | String getProfileId() | setProfileId(String profileId) |
| `ProfileName` | `String` | Optional | - | String getProfileName() | setProfileName(String profileName) |

## Example (as JSON)

```json
{
  "profileId": "HSS-EsmProfile_Enterprise",
  "profileName": "HSS EsmProfile Enterprise"
}
```

