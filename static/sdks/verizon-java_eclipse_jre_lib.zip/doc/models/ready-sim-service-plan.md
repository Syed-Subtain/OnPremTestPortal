
# Ready Sim Service Plan

## Structure

`ReadySimServicePlan`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ServicePlan` | `String` | Optional | - | String getServicePlan() | setServicePlan(String servicePlan) |

## Example (as JSON)

```json
{
  "servicePlan": "123456"
}
```

