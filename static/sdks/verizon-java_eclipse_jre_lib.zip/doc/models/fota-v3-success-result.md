
# Fota V3 Success Result

Cancelation status.

## Structure

`FotaV3SuccessResult`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Success` | `boolean` | Required | True or false. | boolean getSuccess() | setSuccess(boolean success) |

## Example (as JSON)

```json
{
  "success": true
}
```

