
# Coordinate

## Structure

`Coordinate`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Latitude` | `String` | Optional | **Constraints**: *Maximum Length*: `10`, *Pattern*: `^\d2\.\d*$` | String getLatitude() | setLatitude(String latitude) |
| `Longitude` | `String` | Optional | **Constraints**: *Maximum Length*: `10`, *Pattern*: `^\d2\.\d*$` | String getLongitude() | setLongitude(String longitude) |

## Example (as JSON)

```json
{
  "latitude": "latitude8",
  "longitude": "longitude2"
}
```

