
# Fields 2

List of fields affected by the event.

## Structure

`Fields2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Temperature` | `String` | Optional | - | String getTemperature() | setTemperature(String temperature) |

## Example (as JSON)

```json
{
  "temperature": "18.4"
}
```

