
# Campaign Meta Info Protocol Enum

Firmware protocol. Valid values include: LWM2M, OMD-DM.

## Enumeration

`CampaignMetaInfoProtocolEnum`

## Fields

| Name |
|  --- |
| `LWM2m` |
| `OMDDM` |

## Example

```
LWM2M
```

