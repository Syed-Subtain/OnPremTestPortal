
# Enable Promo Exp

## Structure

`EnablePromoExp`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `EnablePromoExp` | `Boolean` | Optional | - | Boolean getEnablePromoExp() | setEnablePromoExp(Boolean enablePromoExp) |

## Example (as JSON)

```json
{
  "enablePromoExp": true
}
```

