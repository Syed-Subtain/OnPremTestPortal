
# Connectivity Management Success Result

Response to successful request.

## Structure

`ConnectivityManagementSuccessResult`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Success` | `Boolean` | Optional | A value of “true” indicates that the device group was created successfully. | Boolean getSuccess() | setSuccess(Boolean success) |

## Example (as JSON)

```json
{
  "success": true
}
```

