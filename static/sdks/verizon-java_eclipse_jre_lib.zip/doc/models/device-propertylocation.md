
# Device Propertylocation

## Structure

`DevicePropertylocation`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Latitude` | `String` | Optional | - | String getLatitude() | setLatitude(String latitude) |
| `Longitude` | `String` | Optional | - | String getLongitude() | setLongitude(String longitude) |

## Example (as JSON)

```json
{
  "latitude": "37.2314796",
  "longitude": "-119.4692153"
}
```

