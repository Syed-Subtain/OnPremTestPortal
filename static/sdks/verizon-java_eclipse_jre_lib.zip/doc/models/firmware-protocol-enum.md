
# Firmware Protocol Enum

Firmware protocol. Valid values include: LWM2M, OMD-DM, all.

## Enumeration

`FirmwareProtocolEnum`

## Fields

| Name |
|  --- |
| `LWM2m` |
| `OMDDM` |
| `All` |

## Example

```
LWM2M
```

