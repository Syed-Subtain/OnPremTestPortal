
# Filtercriteria

## Structure

`Filtercriteria`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `FilterCriteria` | [`List<ReadySimServicePlan>`](../../doc/models/ready-sim-service-plan.md) | Optional | - | List<ReadySimServicePlan> getFilterCriteria() | setFilterCriteria(List<ReadySimServicePlan> filterCriteria) |

## Example (as JSON)

```json
{
  "filterCriteria": [
    {
      "servicePlan": "servicePlan4"
    }
  ]
}
```

