
# Ready Sim Device Id

## Structure

`ReadySimDeviceId`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Kind` | `String` | Optional | - | String getKind() | setKind(String kind) |
| `Id` | `String` | Optional | - | String getId() | setId(String id) |

## Example (as JSON)

```json
{
  "kind": "iccid",
  "id": "20-digit iccid"
}
```

