
# Device List

## Structure

`DeviceList`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `DeviceIds` | [`List<DeviceId>`](../../doc/models/device-id.md) | Optional | **Constraints**: *Maximum Items*: `100` | List<DeviceId> getDeviceIds() | setDeviceIds(List<DeviceId> deviceIds) |

## Example (as JSON)

```json
{
  "deviceIds": [
    {
      "id": "id0",
      "kind": "kind8"
    },
    {
      "id": "id0",
      "kind": "kind8"
    },
    {
      "id": "id0",
      "kind": "kind8"
    }
  ]
}
```

