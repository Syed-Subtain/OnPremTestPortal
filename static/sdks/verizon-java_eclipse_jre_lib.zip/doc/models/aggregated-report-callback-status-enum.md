
# Aggregated Report Callback Status Enum

QUEUED or COMPLETED. Requests for IoT devices with cacheMode=0 (cached) have status=COMPLETED; all other requests are QUEUED.

## Enumeration

`AggregatedReportCallbackStatusEnum`

## Fields

| Name |
|  --- |
| `QUEUED` |
| `COMPLETED` |

## Example

```
QUEUED
```

