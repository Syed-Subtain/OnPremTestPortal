
# IMP Network Type Enum

The type of the device's network connection at the time of the request. If the device is on the Verizon cellular network it should use the "VZ" value otherwise the "non-VZ" value.

Devices on the Verizon network can directly access the IMP Message Exchange on the MEC (Mobile Edge Compute server)

## Enumeration

`IMPNetworkTypeEnum`

## Fields

| Name |
|  --- |
| `VZ` |
| `NonVZ` |

## Example

```
non-VZ
```

