
# Activate

## Structure

`Activate`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Profile` | `String` | Required | - | String getProfile() | setProfile(String profile) |

## Example (as JSON)

```json
{
  "profile": "HSS EsmProfile Enterprise 5G"
}
```

