
# Response Code Enum

Possible response codes.

## Enumeration

`ResponseCodeEnum`

## Fields

| Name |
|  --- |
| `INVALIDACCESS` |
| `INVALIDPARAMETER` |
| `INTERNALERROR` |
| `SUCCESS` |

## Example

```
INVALID_ACCESS
```

