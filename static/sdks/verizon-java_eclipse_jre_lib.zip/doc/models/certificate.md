
# Certificate

Structure for the credentials required to connect to the IMP MQTT Message Exchange.

## Structure

`Certificate`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `CertPem` | `String` | Required | The string containing the certificate<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `4096`, *Pattern*: `^[a-zA-Z0-9~\+\-!@#$%^&*()\`\[\]{=};\"':,.\/<>?\|\s]+$` | String getCertPem() | setCertPem(String certPem) |
| `KeyPem` | `String` | Required | The string containing the private key<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `4096`, *Pattern*: `^[a-zA-Z0-9~\+\-!@#$%^&*()\`\[\]{=};\"':,.\/<>?\|\s]+$` | String getKeyPem() | setKeyPem(String keyPem) |

## Example (as JSON)

```json
{
  "cert.pem": "\"-----BEGIN CERTIFICATE-----\nMIIDrjCCApagAwIBAgICEAEwDQYJKoZIhvcNAQELBQAwUjELMAkGA1UEBhMCQVUx\n...\nuuA1Zog3aBOeeEzp9SEJBMTJRYPXbK4e8Xer+7m98OL/3g==\n-----END CERTIFICATE-----\" \n",
  "key.pem": "\"-----BEGIN PRIVATE KEY-----\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQDa1lF7DWudshQ5\n...\nJbjD2hacWGzpKzTfn5Mt1frE\n-----END PRIVATE KEY-----\"\n"
}
```

