
# Cycle Type Enum

## Enumeration

`CycleTypeEnum`

## Fields

| Name |
|  --- |
| `Cycleone` |
| `Cycletwo` |

