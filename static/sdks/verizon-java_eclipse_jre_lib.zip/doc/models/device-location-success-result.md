
# Device Location Success Result

Whether the device location request was successful or not.

## Structure

`DeviceLocationSuccessResult`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Success` | `Boolean` | Optional | - | Boolean getSuccess() | setSuccess(Boolean success) |

## Example (as JSON)

```json
{
  "success": true
}
```

