
# Polygon

## Structure

`Polygon`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Type` | `String` | Optional | **Constraints**: *Maximum Length*: `10`, *Pattern*: `^[a-zA-Z0-9]*$` | String getType() | setType(String type) |
| `Coordinates` | [`List<Coordinate>`](../../doc/models/coordinate.md) | Optional | **Constraints**: *Maximum Items*: `20` | List<Coordinate> getCoordinates() | setCoordinates(List<Coordinate> coordinates) |

## Example (as JSON)

```json
{
  "type": "Polygon",
  "coordinates": [
    {
      "latitude": "latitude4",
      "longitude": "longitude4"
    }
  ]
}
```

