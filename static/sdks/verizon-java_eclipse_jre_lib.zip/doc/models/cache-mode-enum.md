
# Cache Mode Enum

Location cache mode.

## Enumeration

`CacheModeEnum`

## Fields

| Name |
|  --- |
| `Enum0` |
| `Enum1` |
| `Enum2` |

## Example

```
1
```

