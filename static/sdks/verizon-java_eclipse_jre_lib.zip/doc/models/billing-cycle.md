
# Billing Cycle

## Structure

`BillingCycle`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Year` | `String` | Optional | - | String getYear() | setYear(String year) |
| `Month` | `String` | Optional | - | String getMonth() | setMonth(String month) |

## Example (as JSON)

```json
{
  "year": "2020",
  "month": "3"
}
```

