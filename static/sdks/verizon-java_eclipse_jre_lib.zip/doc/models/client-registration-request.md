
# Client Registration Request

Request for /clients/registration endpoint. It requires the Client Type, Subtype and Vendor to be defined.

## Structure

`ClientRegistrationRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ClientType` | `Object` | Required | - | Object getClientType() | setClientType(Object clientType) |
| `ClientSubtype` | [`ClientSubtypeEnum`](../../doc/models/client-subtype-enum.md) | Required | The subtype or subgroup of the client type. This further specifies the client type. For example it will specify if the client is a passenger car or a truck. See the ClientType description for the supported Subtypes for each client type. | ClientSubtypeEnum getClientSubtype() | setClientSubtype(ClientSubtypeEnum clientSubtype) |
| `VendorID` | `String` | Required | The vendor that the client belongs to. E.g. Verizon, GM, Ford, etc.<br>**Constraints**: *Maximum Length*: `64`, *Pattern*: `^[a-zA-Z0-9]+$` | String getVendorID() | setVendorID(String vendorID) |

## Example (as JSON)

```json
{
  "ClientType": {
    "key1": "val1",
    "key2": "val2"
  },
  "ClientSubtype": "Bus",
  "VendorID": "Verizon"
}
```

