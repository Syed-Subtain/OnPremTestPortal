
# Action Type Enum

The type of action the vendor registration service took for the request

Values:

- **Added** - A new vendor was added to the system
- **Updated** - The existing vendor was updated with the newly provided properties

## Enumeration

`ActionTypeEnum`

## Fields

| Name |
|  --- |
| `Added` |
| `Updated` |

## Example

```
Added
```

