
# Intelligence Success Result

Success response.

## Structure

`IntelligenceSuccessResult`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Status` | `String` | Optional | Anomaly detection status. | String getStatus() | setStatus(String status) |

## Example (as JSON)

```json
{
  "status": "Success"
}
```

