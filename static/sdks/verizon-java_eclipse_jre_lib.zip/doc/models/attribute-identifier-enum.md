
# Attribute Identifier Enum

Attribute identifier.

## Enumeration

`AttributeIdentifierEnum`

## Fields

| Name |
|  --- |
| `NETWORKBEARER` |
| `RADIOSIGNALSTRENGTH` |
| `LINKQUALITY` |
| `CELLID` |
| `MANUFACTURER` |

## Example

```
RADIO_SIGNAL_STRENGTH
```

