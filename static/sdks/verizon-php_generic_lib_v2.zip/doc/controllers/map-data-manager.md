# Map Data Manager

```php
$mapDataManagerController = $client->getMapDataManagerController();
```

## Class Name

`MapDataManagerController`

## Methods

* [Upload Map Data Message](../../doc/controllers/map-data-manager.md#upload-map-data-message)
* [Download Map Data Message](../../doc/controllers/map-data-manager.md#download-map-data-message)


# Upload Map Data Message

This endpoint allows user to upload map messages in asn.1 J2735 encoded format. The MapData can have one or more intersections.

```php
function uploadMapDataMessage(string $basicToken, string $username, string $password, string $body): ApiResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `basicToken` | `string` | Header, Required | This is the Basic (authentication) token for the user. It should be acquired by using the ThingSpace Portal (thingspace.verizon.com). |
| `username` | `string` | Header, Required | This is the UWS login name for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `password` | `string` | Header, Required | This is the UWS password for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `body` | `string` | Body, Required | - |

## Response Type

This method returns a `VerizonLib\Utils\ApiResponse` instance. The `getResult()` method on this instance returns the response data which is of type `string`.

## Example Usage

```php
$basicToken = 'RGFrb3RhQ2xpZWnTAtYjNhMjGyYWE0ZWMz';

$username = 'VerizonImpUser';

$password = 'Some-Password_123';

$body = 'body6';

$apiResponse = $mapDataManagerController->uploadMapDataMessage(
    $basicToken,
    $username,
    $password,
    $body
);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid request | [`MapDataResponseErrorException`](../../doc/models/map-data-response-error-exception.md) |
| 401 | Unauthorized | [`MapDataResponseErrorException`](../../doc/models/map-data-response-error-exception.md) |
| 403 | Forbidden Request | [`MapDataResponseErrorException`](../../doc/models/map-data-response-error-exception.md) |
| 429 | Too Many Requests | [`MapDataResponseErrorException`](../../doc/models/map-data-response-error-exception.md) |
| 503 | Internal server Error | [`MapDataResponseErrorException`](../../doc/models/map-data-response-error-exception.md) |
| Default | Forbidden | [`MapDataResponseErrorException`](../../doc/models/map-data-response-error-exception.md) |


# Download Map Data Message

This endpoint allows user to download SAE J2735 MAP messages in ASN.1 UPER format. The area for the MAP messages is needed to be defined in the query.

```php
function downloadMapDataMessage(
    string $basicToken,
    string $username,
    string $password,
    Polygon $geoFence
): ApiResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `basicToken` | `string` | Header, Required | This is the Basic (authentication) token for the user. It should be acquired by using the ThingSpace Portal (thingspace.verizon.com). |
| `username` | `string` | Header, Required | This is the UWS login name for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `password` | `string` | Header, Required | This is the UWS password for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `geoFence` | [`Polygon`](../../doc/models/polygon.md) | Query, Required | - |

## Response Type

This method returns a `VerizonLib\Utils\ApiResponse` instance. The `getResult()` method on this instance returns the response data which is of type `string`.

## Example Usage

```php
$basicToken = 'RGFrb3RhQ2xpZWnTAtYjNhMjGyYWE0ZWMz';

$username = 'Imp-Us3r@verizon.com';

$password = 'Some-Password_123';

$geoFence = PolygonBuilder::init()
    ->type('Polygon')
    ->build();

$apiResponse = $mapDataManagerController->downloadMapDataMessage(
    $basicToken,
    $username,
    $password,
    $geoFence
);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Unauthorized | [`MapDataResponseErrorException`](../../doc/models/map-data-response-error-exception.md) |
| 403 | Forbidden Request | [`MapDataResponseErrorException`](../../doc/models/map-data-response-error-exception.md) |
| 429 | Too Many Requests | [`MapDataResponseErrorException`](../../doc/models/map-data-response-error-exception.md) |
| 503 | Internal server Error | [`MapDataResponseErrorException`](../../doc/models/map-data-response-error-exception.md) |
| Default | Forbidden | [`MapDataResponseErrorException`](../../doc/models/map-data-response-error-exception.md) |

