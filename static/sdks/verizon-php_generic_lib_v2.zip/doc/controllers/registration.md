# Registration

```php
$registrationController = $client->getRegistrationController();
```

## Class Name

`RegistrationController`

## Methods

* [Register IMP Vendor](../../doc/controllers/registration.md#register-imp-vendor)
* [Unregister IMP Vendor](../../doc/controllers/registration.md#unregister-imp-vendor)
* [Register IMP Device](../../doc/controllers/registration.md#register-imp-device)
* [Unregister IMP Device](../../doc/controllers/registration.md#unregister-imp-device)
* [Retrieve MQT Turl](../../doc/controllers/registration.md#retrieve-mqt-turl)


# Register IMP Vendor

With this API call the users (clients) register themselves as Vendors to the IMP system. Therefore, when a registration is initiated from a device or software service to the IMP system with the registered VendorID, then the client registration will be authorized.

```php
function registerIMPVendor(
    string $basicToken,
    string $username,
    string $password,
    VendorRegistrationRequest $body
): ApiResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `basicToken` | `string` | Header, Required | This is the Basic (authentication) token for the user. It should be acquired by using the ThingSpace Portal (thingspace.verizon.com). |
| `username` | `string` | Header, Required | This is the UWS login name for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `password` | `string` | Header, Required | This is the UWS password for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `body` | [`VendorRegistrationRequest`](../../doc/models/vendor-registration-request.md) | Body, Required | - |

## Response Type

This method returns a `VerizonLib\Utils\ApiResponse` instance. The `getResult()` method on this instance returns the response data which is of type [`VendorRegistrationResponse`](../../doc/models/vendor-registration-response.md).

## Example Usage

```php
$basicToken = 'RGFrb3RhQ2xpZWnTAtYjNhMjGyYWE0ZWMz';

$username = 'VerizonImpUser';

$password = 'Some-Password_123';

$body = VendorRegistrationRequestBuilder::init(
    'VerizonIMP',
    '0242080520-00001'
)->build();

$apiResponse = $registrationController->registerIMPVendor(
    $basicToken,
    $username,
    $password,
    $body
);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid Request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 401 | Unauthorized Request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 403 | Forbidden Request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 429 | Too Many Requests | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 503 | Internal Server Error | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| Default | Forbidden | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |


# Unregister IMP Vendor

With this API call the users (clients) can unregister themselves from the IMP system. The devices and services for this Vendor will no longer be able to use the IMP Message Exchange.

```php
function unregisterIMPVendor(
    string $basicToken,
    string $username,
    string $password,
    string $vendorID
): ApiResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `basicToken` | `string` | Header, Required | This is the Basic (authentication) token for the user. It should be acquired by using the ThingSpace Portal (thingspace.verizon.com). |
| `username` | `string` | Header, Required | This is the UWS login name for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `password` | `string` | Header, Required | This is the UWS password for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `vendorID` | `string` | Query, Required | The VendorID set during the Vendor registration call. |

## Response Type

This method returns a `VerizonLib\Utils\ApiResponse` instance.

## Example Usage

```php
$basicToken = 'RGFrb3RhQ2xpZWnTAtYjNhMjGyYWE0ZWMz';

$username = 'VerizonImpUser';

$password = 'Some-Password_123';

$vendorID = 'VerizonIMP';

$apiResponse = $registrationController->unregisterIMPVendor(
    $basicToken,
    $username,
    $password,
    $vendorID
);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid Request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 401 | Unauthorized Request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 403 | Forbidden Request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 429 | Too Many Requests | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 503 | Internal Server Error | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| Default | Forbidden | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |


# Register IMP Device

With this API call the user (client) registers its device or software service to the IMP system. Therefore, when a connection is initiated from the device or software service to the IMP system along with the credential provided by this registration call, then the connection will be authorized.
Note 1: One user can register multiple devices or software services, which can all be used at the same time.

Note 2: The user needs to authenticate with their ThingSpace credentials and request a bearer token in order to call this API.

```php
function registerIMPDevice(string $username, string $password, ClientRegistrationRequest $body): ApiResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `username` | `string` | Header, Required | This is the UWS login name for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `password` | `string` | Header, Required | This is the UWS password for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `body` | [`ClientRegistrationRequest`](../../doc/models/client-registration-request.md) | Body, Required | - |

## Response Type

This method returns a `VerizonLib\Utils\ApiResponse` instance. The `getResult()` method on this instance returns the response data which is of type [`ClientRegistrationResponse`](../../doc/models/client-registration-response.md).

## Example Usage

```php
$username = 'VerizonImpUser';

$password = 'Some-Password_123';

$body = ClientRegistrationRequestBuilder::init(
    ApiHelper::deserialize('{"key1":"val1","key2":"val2"}'),
    ClientSubtypeEnum::MAINTENANCEVEHICLE,
    'Verizon'
)->build();

$apiResponse = $registrationController->registerIMPDevice(
    $username,
    $password,
    $body
);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid Request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 401 | Unauthorized Request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 403 | Forbidden Request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 429 | Too Many Requests | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 503 | Internal Server Error | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| Default | Forbidden | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |


# Unregister IMP Device

With this API call the user (client) can unregister its devices and software services from the IMP system. The unregistered devices and services will no longer be able to use the IMP Message Exchange.

```php
function unregisterIMPDevice(string $username, string $password, array $deviceIDs): ApiResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `username` | `string` | Header, Required | This is the UWS login name for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `password` | `string` | Header, Required | This is the UWS password for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `deviceIDs` | `string[]` | Query, Required | The Device IDs acquired through the registration API. |

## Response Type

This method returns a `VerizonLib\Utils\ApiResponse` instance.

## Example Usage

```php
$username = 'VerizonImpUser';

$password = 'Some-Password_123';

$deviceIDs = [
    '0000225a-0000-0000-0000-000000000000'
];

$apiResponse = $registrationController->unregisterIMPDevice(
    $username,
    $password,
    $deviceIDs
);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid Request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 401 | Unauthorized Request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 403 | Forbidden Request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 429 | Too Many Requests | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 503 | Internal Server Error | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| Default | Forbidden | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |


# Retrieve MQT Turl

With this API call the  or software service requests the MQTT URL for the location that it needs to connect. To determine the proper URL the device or software service needs to provide its ID (the one that was provided in the registration request), location (GPS coordinates), and whether it is on the Verizon cellular network or not.

Note: The user needs to authenticate with their ThingSpace credentials and request a bearer token in order to call this API.

```php
function retrieveMQTTurl(
    string $username,
    string $password,
    string $vendorID,
    ConnectionRequest $body
): ApiResponse
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `username` | `string` | Header, Required | This is the UWS login name for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `password` | `string` | Header, Required | This is the UWS password for the user. It should be acquired by using the ThingSpace Connectivity Management Portal (thingspace.verizonwireless.com). |
| `vendorID` | `string` | Header, Required | The VendorID set during the Vendor registration call. |
| `body` | [`ConnectionRequest`](../../doc/models/connection-request.md) | Body, Required | - |

## Response Type

This method returns a `VerizonLib\Utils\ApiResponse` instance. The `getResult()` method on this instance returns the response data which is of type [`ConnectionResponse`](../../doc/models/connection-response.md).

## Example Usage

```php
$username = 'VerizonImpUser';

$password = 'Some-Password_123';

$vendorID = 'VerizonIMP';

$body = ConnectionRequestBuilder::init(
    '976c4bad-03d3-4dcb-9688-ee57db7890e4',
    GeolocationBuilder::init(
        42.36,
        -71.06
    )->build(),
    ApiHelper::deserialize('{"key1":"val1","key2":"val2"}')
)->build();

$apiResponse = $registrationController->retrieveMQTTurl(
    $username,
    $password,
    $vendorID,
    $body
);
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Invalid request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 401 | Unauthorized | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 403 | Forbidden Request | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 429 | Too Many Requests | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| 503 | Internal server Error | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |
| Default | Forbidden | [`IMPResponseErrorException`](../../doc/models/imp-response-error-exception.md) |

