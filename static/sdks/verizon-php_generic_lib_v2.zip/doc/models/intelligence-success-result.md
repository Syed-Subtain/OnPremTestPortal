
# Intelligence Success Result

Success response.

## Structure

`IntelligenceSuccessResult`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `status` | `?string` | Optional | Anomaly detection status. | getStatus(): ?string | setStatus(?string status): void |

## Example (as JSON)

```json
{
  "status": "Success"
}
```

