
# Cache Mode Enum

Location cache mode.

## Enumeration

`CacheModeEnum`

## Fields

| Name |
|  --- |
| `ENUM_0` |
| `ENUM_1` |
| `ENUM_2` |

## Example

```
1
```

