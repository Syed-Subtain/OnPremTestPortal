
# Cycle Type Enum

## Enumeration

`CycleTypeEnum`

## Fields

| Name |
|  --- |
| `CYCLEONE` |
| `CYCLETWO` |

