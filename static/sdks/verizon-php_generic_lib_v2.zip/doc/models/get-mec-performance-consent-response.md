
# Get MEC Performance Consent Response

MEC Performance Consent Response

## Structure

`GetMECPerformanceConsentResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `consent` | `?string` | Optional | MEC Performance Consent Response. | getConsent(): ?string | setConsent(?string consent): void |

## Example (as JSON)

```json
{
  "consent": "false"
}
```

