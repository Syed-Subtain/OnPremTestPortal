
# Filtercriteria

## Structure

`Filtercriteria`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `filterCriteria` | [`?(ReadySimServicePlan[])`](../../doc/models/ready-sim-service-plan.md) | Optional | - | getFilterCriteria(): ?array | setFilterCriteria(?array filterCriteria): void |

## Example (as JSON)

```json
{
  "filterCriteria": [
    {
      "servicePlan": "servicePlan4"
    }
  ]
}
```

