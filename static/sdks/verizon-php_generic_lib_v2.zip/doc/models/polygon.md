
# Polygon

## Structure

`Polygon`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `type` | `?string` | Optional | **Constraints**: *Maximum Length*: `10`, *Pattern*: `^[a-zA-Z0-9]*$` | getType(): ?string | setType(?string type): void |
| `coordinates` | [`?(Coordinate[])`](../../doc/models/coordinate.md) | Optional | **Constraints**: *Maximum Items*: `20` | getCoordinates(): ?array | setCoordinates(?array coordinates): void |

## Example (as JSON)

```json
{
  "type": "Polygon",
  "coordinates": [
    {
      "latitude": "latitude4",
      "longitude": "longitude4"
    }
  ]
}
```

