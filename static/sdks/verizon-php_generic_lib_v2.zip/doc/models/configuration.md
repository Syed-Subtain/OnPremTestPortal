
# Configuration

List of the field names and values to set.

## Structure

`Configuration`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `frequency` | `?string` | Optional | - | getFrequency(): ?string | setFrequency(?string frequency): void |

## Example (as JSON)

```json
{
  "frequency": "Low"
}
```

