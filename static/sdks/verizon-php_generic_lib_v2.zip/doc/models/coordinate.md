
# Coordinate

## Structure

`Coordinate`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `latitude` | `?string` | Optional | **Constraints**: *Maximum Length*: `10`, *Pattern*: `^\d2\.\d*$` | getLatitude(): ?string | setLatitude(?string latitude): void |
| `longitude` | `?string` | Optional | **Constraints**: *Maximum Length*: `10`, *Pattern*: `^\d2\.\d*$` | getLongitude(): ?string | setLongitude(?string longitude): void |

## Example (as JSON)

```json
{
  "latitude": "latitude8",
  "longitude": "longitude2"
}
```

