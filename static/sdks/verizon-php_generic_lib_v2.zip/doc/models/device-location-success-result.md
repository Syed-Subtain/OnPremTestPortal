
# Device Location Success Result

Whether the device location request was successful or not.

## Structure

`DeviceLocationSuccessResult`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `success` | `?bool` | Optional | - | getSuccess(): ?bool | setSuccess(?bool success): void |

## Example (as JSON)

```json
{
  "success": true
}
```

