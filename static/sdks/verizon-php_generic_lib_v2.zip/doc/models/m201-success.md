
# M201 Success

## Structure

`M201success`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `requestId` | `?string` | Optional | - | getRequestId(): ?string | setRequestId(?string requestId): void |

## Example (as JSON)

```json
{
  "requestId": "be36accb-0a9a-4367-93ab-0af6c4ed256a"
}
```

