
# Activate

## Structure

`Activate`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `profile` | `string` | Required | - | getProfile(): string | setProfile(string profile): void |

## Example (as JSON)

```json
{
  "profile": "HSS EsmProfile Enterprise 5G"
}
```

