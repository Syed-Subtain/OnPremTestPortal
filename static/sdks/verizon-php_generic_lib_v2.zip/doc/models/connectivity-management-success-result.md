
# Connectivity Management Success Result

Response to successful request.

## Structure

`ConnectivityManagementSuccessResult`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `success` | `?bool` | Optional | A value of “true” indicates that the device group was created successfully. | getSuccess(): ?bool | setSuccess(?bool success): void |

## Example (as JSON)

```json
{
  "success": true
}
```

