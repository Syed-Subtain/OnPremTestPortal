
# Accuracy Mode Enum

Accurary, currently only 0-coarse supported.

## Enumeration

`AccuracyModeEnum`

## Fields

| Name |
|  --- |
| `ENUM_0` |

## Example

```
0
```

