
# Error Response Code Enum

Error Code.

## Enumeration

`ErrorResponseCodeEnum`

## Fields

| Name |
|  --- |
| `INVALID_ACCESS` |
| `INVALID_PARAMETER` |
| `INTERNAL_ERROR` |
| `SUCCESS` |

## Example

```
INVALID_ACCESS
```

