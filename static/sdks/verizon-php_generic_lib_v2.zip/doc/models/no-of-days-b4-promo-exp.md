
# No of Days B4 Promo Exp

## Structure

`NoOfDaysB4PromoExp`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `key` | `?string` | Optional | - | getKey(): ?string | setKey(?string key): void |
| `value` | `?int` | Optional | - | getValue(): ?int | setValue(?int value): void |

## Example (as JSON)

```json
{
  "key": "NoOfDaysB4PromoExp",
  "value": 5
}
```

