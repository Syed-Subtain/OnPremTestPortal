
# Fields 2

List of fields affected by the event.

## Structure

`Fields2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `temperature` | `?string` | Optional | - | getTemperature(): ?string | setTemperature(?string temperature): void |

## Example (as JSON)

```json
{
  "temperature": "18.4"
}
```

