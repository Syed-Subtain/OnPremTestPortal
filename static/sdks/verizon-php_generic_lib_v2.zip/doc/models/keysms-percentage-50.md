
# Keysms Percentage 50

## Structure

`KeysmsPercentage50`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `key` | `?string` | Optional | - | getKey(): ?string | setKey(?string key): void |
| `value` | `?bool` | Optional | - | getValue(): ?bool | setValue(?bool value): void |

## Example (as JSON)

```json
{
  "key": "SmsPercentage50",
  "value": false
}
```

