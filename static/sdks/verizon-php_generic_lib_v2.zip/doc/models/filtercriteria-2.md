
# Filtercriteria 2

## Structure

`Filtercriteria2`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `filterCriteria` | `?(array[])` | Optional | - | getFilterCriteria(): ?array | setFilterCriteria(?array filterCriteria): void |

## Example (as JSON)

```json
{
  "filterCriteria": [
    {
      "key1": "val1",
      "key2": "val2"
    }
  ]
}
```

