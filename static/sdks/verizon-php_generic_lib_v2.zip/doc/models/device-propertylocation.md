
# Device Propertylocation

## Structure

`DevicePropertylocation`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `latitude` | `?string` | Optional | - | getLatitude(): ?string | setLatitude(?string latitude): void |
| `longitude` | `?string` | Optional | - | getLongitude(): ?string | setLongitude(?string longitude): void |

## Example (as JSON)

```json
{
  "latitude": "37.2314796",
  "longitude": "-119.4692153"
}
```

