
# Connection Response

response for /clients/connection

## Structure

`ConnectionResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `mqttURL` | `string` | Required | **Constraints**: *Maximum Length*: `1024`, *Pattern*: `^(http?mqtt)://[^\s/$.?#].[^\s]*$` | getMqttURL(): string | setMqttURL(string mqttURL): void |

## Example (as JSON)

```json
{
  "MqttURL": "MqttURL2"
}
```

