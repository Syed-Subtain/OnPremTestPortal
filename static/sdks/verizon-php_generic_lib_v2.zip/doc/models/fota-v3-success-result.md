
# Fota V3 Success Result

Cancelation status.

## Structure

`FotaV3SuccessResult`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `success` | `bool` | Required | True or false. | getSuccess(): bool | setSuccess(bool success): void |

## Example (as JSON)

```json
{
  "success": true
}
```

