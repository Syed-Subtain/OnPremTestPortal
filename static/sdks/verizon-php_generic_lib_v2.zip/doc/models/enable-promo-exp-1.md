
# Enable Promo Exp 1

## Structure

`EnablePromoExp1`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `key` | `?string` | Optional | - | getKey(): ?string | setKey(?string key): void |
| `value` | `?bool` | Optional | - | getValue(): ?bool | setValue(?bool value): void |

## Example (as JSON)

```json
{
  "key": "EnablePromoExp",
  "value": true
}
```

