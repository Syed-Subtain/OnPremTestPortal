
# Download Time Window

## Structure

`DownloadTimeWindow`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `startTime` | `?string` | Optional | Device IMEI list. | getStartTime(): ?string | setStartTime(?string startTime): void |
| `endTime` | `?string` | Optional | Device IMEI list. | getEndTime(): ?string | setEndTime(?string endTime): void |

## Example (as JSON)

```json
{
  "startTime": "0",
  "endTime": "0"
}
```

