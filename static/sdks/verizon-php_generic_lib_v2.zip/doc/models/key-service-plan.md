
# Key Service Plan

## Structure

`KeyServicePlan`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `key` | `?string` | Optional | - | getKey(): ?string | setKey(?string key): void |

## Example (as JSON)

```json
{
  "key": "ServicePlan"
}
```

