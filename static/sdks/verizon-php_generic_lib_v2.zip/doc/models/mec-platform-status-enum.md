
# MEC Platform Status Enum

Status of the MEC Platform (default is 'unknown')

## Enumeration

`MECPlatformStatusEnum`

## Fields

| Name |
|  --- |
| `ACTIVE` |
| `INACTIVE` |
| `UNKNOWN` |

