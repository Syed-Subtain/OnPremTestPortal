
# Campaign Meta Info Protocol Enum

Firmware protocol. Valid values include: LWM2M, OMD-DM.

## Enumeration

`CampaignMetaInfoProtocolEnum`

## Fields

| Name |
|  --- |
| `LW_M2M` |
| `OMDDM` |

## Example

```
LWM2M
```

