
# Acceleration

## Structure

`Acceleration`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `x` | `?string` | Optional | - | getX(): ?string | setX(?string x): void |
| `y` | `?string` | Optional | - | getY(): ?string | setY(?string y): void |
| `z` | `?string` | Optional | - | getZ(): ?string | setZ(?string z): void |

## Example (as JSON)

```json
{
  "x": "0.0277",
  "y": "-1.0334",
  "z": "-0.0134"
}
```

