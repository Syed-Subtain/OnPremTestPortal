
# Billing Cycle

## Structure

`BillingCycle`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `year` | `?string` | Optional | - | getYear(): ?string | setYear(?string year): void |
| `month` | `?string` | Optional | - | getMonth(): ?string | setMonth(?string month): void |

## Example (as JSON)

```json
{
  "year": "2020",
  "month": "3"
}
```

