
# Fota V2 Success Result

Response to a successful request.

## Structure

`FotaV2SuccessResult`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `success` | `bool` | Required | - | getSuccess(): bool | setSuccess(bool success): void |

## Example (as JSON)

```json
{
  "success": true
}
```

